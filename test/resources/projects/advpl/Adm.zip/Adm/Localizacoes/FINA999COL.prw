#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'fina999.ch'

#DEFINE SOURCEFATHER "FINA999"

/*/{Protheus.doc} FINA999COL
	Fuente de Modelo de Datos de Orden de Pago Localizado para Colombia
	@type 		Function
	@author 	carlos.espinoza
	@since 		01/10/2026
	@version	12.1.2310 / Superior
/*/
Function FINA999COL()
Local oBrowse	:= Nil

	oBrowse := BrowseDef()
	oBrowse:Activate()
	
Return Nil

/*/{Protheus.doc} BrowseDef
	Definici�n de Browse
	@type 		Function
	@author	 	carlos.espinoza
	@since 		01/10/2026
	@version	12.1.2310 / Superior
/*/
Static Function BrowseDef()
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
	Define las operaciones que ser�n realizadas por la aplicaci�n
	@type 		Function
	@author 	carlos.espinoza
	@since 		01/10/2026
	@version	12.1.2310 / Superior
/*/
Static Function MenuDef()
Local aRotina := {}
	
aRotina := FWLoadMenuDef(SOURCEFATHER)

Return aRotina

/*/{Protheus.doc} ModelDef
	Defini��o do modelo de Dados
	@type 		Function
	@author 	carlos.espinoza
	@since 		01/10/2026
	@version	12.1.2310 / Superior
	@return		Object, Modelo de dados
/*/
Static Function ModelDef()
Local oModel		:= FwLoadModel(SOURCEFATHER)
Local oPgoEvent		:= F999PGOCOL():New()

	//Evento del Modelo
	oModel:InstallEvent("F999PGOCOL","F999PGO" ,oPgoEvent)

Return oModel

/*/{Protheus.doc} ViewDef
	Interface del modelo de datos de Orden de Pago
	@type 		Function
	@author 	carlos.espinoza
	@since 		01/10/2026
	@version	12.1.2310 / Superior
	@return		Object, Vista del Modelo de dados
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)
Local oModel    := Nil

	oModel := oView:GetModel()

Return oView
