#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} F999PGOCOL
	Clase responsable por el evento de reglas de negocio referente al proceso formas de pago para Colombia
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		01/10/2026
/*/
Class F999PGOCOL From FwModelEvent 

	Method New() CONSTRUCTOR
	
	Method VldActivate()

EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		01/10/2026
/*/
Method New() Class F999PGOCOL
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		01/10/2026
	@return		Logical, Resultado de la validaci�n
/*/
Method VldActivate() Class F999PGOCOL
Local lRet	:= .T.

	self:GetEvent("F999PGO"):lAjusITF   := .T.

Return lRet
