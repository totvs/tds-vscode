#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} F999PA
	Clase responsable por el evento de reglas de negocio de localizaci�n padr�n
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999PA From FwModelEvent 

	DATA cDocCred   As Character

	DATA lModPA	    As Logical

	DATA lPERGenPA  As Logical

	DATA lUsaFlag   As Logical

	DATA lRetPA     As Logical

	DATA nColig     As Numeric

	DATA cSimbol    As Character

	DATA lActTit    As Logical

	DATA lNumOp   	As Logical

	DATA lTotAnt    As Logical

	DATA lTes	    As Logical
	
	DATA lProv   	As Logical

	DATA lCBU   	As Logical

	DATA lSolFun   	As Logical
	
	DATA lMsgUnica  As Logical
	
	DATA lSelPgo   	As Logical

	DATA lIntePMS   As Logical

	DATA lFldDES    As Logical

	DATA lMvNat     As Logical

	DATA cFilSED    As Character

	DATA cFilSE2    As Character

	DATA cFilSA2    As Character

	DATA cFilSF1    As Character

	DATA cFilSFB    As Character

	DATA cFilSFC    As Character

	DATA cFilSD1    As Character

	DATA nTamFBCod  As Numeric

	DATA cNature    As Character

	Method New() CONSTRUCTOR
	
	Method VldActivate()

	Method AfterTTS()

	Method F999MODPA()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999PA
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method VldActivate(oModel) Class F999PA
Local lRet			:= .T.
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')

	self:cDocCred 	:= ""

	self:lModPA 	:= .F.

	self:lPERGenPA 	:= .F.

	self:lUsaFlag	:= SuperGetMV( "MV_CTBFLAG",.T.,.F.)

	self:lRetPA		:= SuperGetMv("MV_RETPA", .F., "N") == "S"

	self:nColig		:= SuperGetMv("MV_RMCOLIG", .F., 0)

	self:cSimbol	:= SuperGetMV("MV_SIMB1", .F., "")

	self:lActTit    := ExistBlock("A085ATIT")

	self:lNumOp		:= oModelTTB:HasField("EK_NUMOP") .And. oModelFJR:HasField("NUMOP")

	self:lTotAnt	:= oModelTTB:HasField("EK_TOTANT")

	self:lTes		:= oModelTTB:HasField("EK_TES")

	self:lProv		:= oModelTTB:HasField("EK_PROV")

	self:lCBU 		:= oModelFJR:HasField("CBU")

	self:lSolFun 	:= oModelFJR:HasField("SOLFUN")

	self:lSelPgo	:= IsInCallStack("SELPAGO")  //Valida si el PA es generado por Generar PA

	self:lMsgUnica	:= IsIntegTop()

	self:lIntePMS   := IntePMS()

	self:lFldDES	:= oModelFJR:HasField("DCONCEP") .And. oModelTTB:HasField("EK_DCONCEP")

	self:lMvNat     := .T.

	self:cFilSED	:= xFilial("SED")

	self:cFilSE2	:= xFilial("SE2")

	self:cFilSA2	:= xFilial("SA2")

	self:cFilSF1	:= xFilial("SF1")

	self:cFilSFB	:= xFilial("SFB")

	self:cFilSFC	:= xFilial("SFC")

	self:cFilSD1	:= xFilial("SD1")

	self:nTamFBCod	:= GetSx3Cache("FB_CODIGO","X3_TAMANHO")

	self:cNature	:= SuperGetMV("MV_2DUPNAT",.F.,"")

Return lRet

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio de retenciones 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		23/04/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method AfterTTS(oModel, cModelId) Class F999PA
Local nOperation	:= oModel:GetOperation()
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelCTB 	:= oModel:GetModel('CTB_DETAIL')
Local oModelSE2 	:= oModel:GetModel('SE2_DETAIL')
Local oModelPAG 	:= oModel:GetModel('PAG_DETAIL')
Local oModelPAU 	:= oModel:GetModel('PAU_DETAIL')
Local nX			:= 0
Local cJCotiz		:= oModelEOP:GetValue("COTIZ")
Local oJCotiz 		:= JsonObject():New()
Local oJTxProm		:= JsonObject():New()
Local nTxPromed 	:= 0	
Local aTxProm   	:= {}
Local aAreaSEK 		:= {}
Local aAreaSE2 		:= {}
Local cFnName       := "FINA850"
Local aAreaSA2      := {}
Local oPGOEvent     := Nil
Local nLenPgo       := 0
Local nPag 			:= 0
Local jHdlPrv		:= JsonObject():New()

	If nOperation == MODEL_OPERATION_INSERT .And. !oModelEOP:GetValue("HASERROR")

		If oModelEOP:GetValue("MODII")
			Pergunte("FIN850P", .F., /*cTitle*/, .F., /*oDlg*/, .T.)
		Else
			Pergunte("FIN85A", .F., /*cTitle*/, .F., /*oDlg*/, .T.)
			cFnName := "FINA085A"
		EndIf
		
		If self:lRetPA .And. MV_PAR11 $ MVPAGANT
			self:cDocCred := MVPAGANT
		ElseIf !(Empty(MV_PAR11) .Or. !(MV_PAR11 $ MV_CPNEG+"|"+MVPAGANT))
			self:cDocCred := MV_PAR11
		EndIf

		oJCotiz:FromJson(cJCotiz)
		If oJCotiz:HasProperty("lCpoCotiz")
			oJTxProm:FromJson(oModelFJR:GetValue("ATXPROM"))
			nTxPromed := oModelFJR:GetValue("NTXPROM")
			aTxProm   := oJTxProm['txprom']
		EndIf

		If self:lModPA .And. !oModelEOP:GetValue("PA")
			self:F999MODPA(oModel)
		EndIf

		
		F999CmpMoe(oModelSOP, oModelMOE)
		For nX := 1	To oModelSOP:Length()
			oModelSOP:GoLine(nX)
			If oModelSOP:GetValue("SALDO") < 0  //Genera pago anticipado
				oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSOP:GetValue("ORDPAGO")}}, .F., .T.)
				If !oModelEOP:GetValue("MODII")
					oModelFJR:LoadValue("NMOERET", oModelSOP:GetValue("MONEDA"))
				EndIf
				aAreaSEK := SEK->(GetArea())
				DbSelectArea("SEK")
				RecLock("SEK",.T.)
				SEK->EK_FILIAL	:= xFilial("SEK")
				SEK->EK_TIPODOC	:= "PA"
				SEK->EK_NUM    	:= oModelFJR:GetValue("FJR_ORDPAG")
				SEK->EK_PARCELA	:= ALLTrim(STR(oModelSOP:GetValue("MONEDA")))
				SEK->EK_TIPO   	:= self:cDocCred
				SEK->EK_FORNECE	:= oModelFJR:GetValue("FJR_FORNEC")
				SEK->EK_LOJA   	:= oModelFJR:GetValue("FJR_LOJA")
				SEK->EK_EMISSAO	:= dDataBase
				SEK->EK_VENCTO 	:= dDataBase
				SEK->EK_VALOR  	:= Abs(oModelSOP:GetValue("SALDO"))
				SEK->EK_SALDO  	:= Abs(oModelSOP:GetValue("SALDO"))
				SEK->EK_VLMOED1	:= Round(xMoeda(Abs(oModelSOP:GetValue("SALDO")),oModelFJR:GetValue("NMOERET"),1,,5,oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET"))),MsDecimais(1))
				SEK->EK_MOEDA  	:= Alltrim(Str(oModelFJR:GetValue("NMOERET")))
				SEK->EK_ORDPAGO	:= oModelFJR:GetValue("FJR_ORDPAG")
				SEK->EK_DTDIGIT	:= dDataBase
				SEK->EK_FORNEPG	:= oModelFJR:GetValue("FJR_FORNEC")
				SEK->EK_LOJAPG 	:= oModelFJR:GetValue("FJR_LOJA")
				SEK->EK_NATUREZ := oModelFJR:GetValue("FJR_NATURE")
	
				If self:lTes
					SEK->EK_TES     := oModelFJR:GetValue("TES")
				EndIf

				If self:lProv
					SEK->EK_PROV    := oModelFJR:GetValue("PROVIN")
				EndIf

				If self:lTotAnt
					SEK->EK_TOTANT  := oModelFJR:GetValue("TOTANT")
				EndIf

				If self:lNumOp
					SEK->EK_NUMOPER := oModelFJR:GetValue("NUMOP")
				EndIf

				If self:lCBU
					SEK->EK_PGCBU	:= oModelFJR:GetValue("CBU")
				EndIf

				If self:lSolFun
					SEK->EK_SOLFUN  := oModelFJR:GetValue("SOLFUN")
				EndIf

				If self:lFldDES
					SEK->EK_DCONCEP := Alltrim(oModelFJR:GetValue("DCONCEP"))
				EndIf

				F999GrvTx(oJCotiz['MonedaCotiz'], nTxPromed, aTxProm, oJCotiz, oModelMOE,, .T.)
				SEK->(MsUnlock())
				RestArea(aAreaSEK)

				If oModelEOP:GetValue("CPGTOELT") <> "1"
					aAreaSE2 := SE2->(GetArea())
					DbSelectArea("SE2")
					RecLock("SE2",.T.)
					SE2->E2_FILIAL	:= xFilial("SE2")
					SE2->E2_NUMLIQ 	:= oModelFJR:GetValue("CLIQUID")
					SE2->E2_NUM    	:= oModelFJR:GetValue("FJR_ORDPAG")
					SE2->E2_PARCELA	:= AllTrim(STR(nX))
					SE2->E2_TIPO   	:= self:cDocCred
					SE2->E2_NATUREZ := oModelFJR:GetValue("FJR_NATURE")
					SE2->E2_FORNECE	:= oModelFJR:GetValue("FJR_FORNEC")
					SE2->E2_LOJA   	:= oModelFJR:GetValue("FJR_LOJA")
					SE2->E2_NOMFOR 	:= oModelFJR:GetValue("NOMBRE")
					SE2->E2_EMISSAO	:= dDataBase
					SE2->E2_EMIS1  	:= dDataBase
					SE2->E2_VENCTO 	:= dDataBase
					SE2->E2_VENCORI	:= dDataBase
					SE2->E2_VENCREA	:= DataValida(dDataBase,.T.)
					SE2->E2_VALOR 	:= Abs(oModelSOP:GetValue("SALDO"))
					SE2->E2_SALDO  	:= Abs(oModelSOP:GetValue("SALDO"))
					SE2->E2_VLCRUZ 	:= Round(xMoeda(Abs(oModelSOP:GetValue("SALDO")),oModelFJR:GetValue("NMOERET"),1,,5,oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET"))),MsDecimais(1))
					SE2->E2_MOEDA  	:= oModelFJR:GetValue("NMOERET")
					SE2->E2_TXMOEDA := oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET")) //Graba la tasa de la moneda
					SE2->E2_STATLIB	:= "03" //Fue liberado nX solicitaci�n de fondos.
					SE2->E2_SITUACA	:= "0"
					SE2->E2_ORDPAGO	:= oModelFJR:GetValue("FJR_ORDPAG")
					SE2->E2_ORIGEM 	:= cFnName
					SE2->E2_FILORIG := cFilAnt
					
					If self:lSelPgo
						SE2->E2_CODAPRO := Alltrim(oModelEOP:GetValue("CAPROV"))
					EndIf

					If !self:lUsaFlag
						SE2->E2_LA := "S"
					EndIf

					If oModelEOP:GetValue("MODII")
						SE2->E2_CODAPRO	:= FJA->FJA_CODAPR
						SE2->E2_DATALIB	:= FJA->FJA_DTOPER
					Else
						aAreaSA2 := SA2->(GetArea())
						DbSelectArea("SA2")
						SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
						SA2->(MsSeek(self:cFilSA2+oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")))

						If self:lMvNat .Or. Empty(oModelFJR:GetValue("FJR_NATURE"))
							If Empty(SA2->A2_NATUREZ)
								SE2->E2_NATUREZ	:= self:cNature
							Else
								SE2->E2_NATUREZ	:= SA2->A2_NATUREZ
							EndIf
						EndIf

						If oModelSE2:HasField("E2_CGC")
							SE2->E2_CGC	:= SA2->A2_CGC
						EndIf

						RestArea(aAreaSA2)
					EndIf

					//Integraci�n Protheus X TOP - Argentina y Mexico
					If !self:lMsgUnica .And. self:nColig > 0 .And. self:lIntePMS .And.  MsgYesNo(OemToAnsi(STR0071)+" "+"("+self:cDocCred+")"+" "+AllTrim(SE2->E2_NUM)+" " +OemToAnsi(STR0072)+" "+;
						self:cSimbol+" "+ AllTrim(Transform(SE2->E2_VLCRUZ,GetSx3Cache("E2_VLCRUZ","X3_PICTURE")))+ " " + OemToAnsi(STR0073))//"Desea vincular el t�tulo" "de valor" "a un proyecto?"
						PMSFi999()
					EndIf

					SE2->(MsUnlock())

					If self:lUsaFlag  //Graba registro en el modelo CTB_DETAIL para ser grabado en el Modulo Contable
						If !oModelCTB:IsEmpty() .And. oModelCTB:GetValue("RECNO") > 0
							oModelCTB:AddLine()
						EndIf
						oModelCTB:SetValue("ORDPAGO", oModelFJR:GetValue("FJR_ORDPAG"))
						oModelCTB:SetValue("CAMPO"	, "E2_LA")
						oModelCTB:SetValue("VALOR"	, "S")
						oModelCTB:SetValue("TABLA"	, "SE2")
						oModelCTB:SetValue("RECNO"	, SE2->(Recno()))
					EndIf

					RestArea(aAreaSE2)

					If self:lActTit
						ExecBLock("A085ATIT",.F.,.F.)
					Endif
				EndIf
			ElseIf oModelSOP:GetValue("SALDO") > 0 .And. !oModelEOP:GetValue("MODII")
				oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSOP:GetValue("ORDPAGO")}}, .F., .T.)
				oPGOEvent := F999PGO():New()
				nLenPgo := oModelPAG:Length()
				oModelPAG:GoLine(nLenPgo)

				If !Empty(oModelPAG:GetValue("EK_ORDPAGO"))
					oModelPAG:AddLine()
				EndIf
				
				oModelPAG:LoadValue("EK_BANCO"	,oModelPAU:GetValue("EK_BANCO"))
				oModelPAG:LoadValue("EK_AGENCIA",oModelPAU:GetValue("EK_AGENCIA"))
				oModelPAG:LoadValue("EK_CONTA"	,oModelPAU:GetValue("EK_CONTA"))
				oModelPAG:LoadValue("EK_PARCELA",oModelPAU:GetValue("EK_PARCELA"))
				oModelPAG:LoadValue("EK_VENCTO"	,oModelPAU:GetValue("EK_VENCTO"))
				oModelPAG:LoadValue("EK_VALOR"	,oModelSOP:GetValue("SALDO"))
				oModelPAG:LoadValue("EK_ORDPAGO",oModelFJR:GetValue("FJR_ORDPAG"))
				oModelPAG:LoadValue("EK_EMISSAO",oModelPAU:GetValue("EK_EMISSAO"))
				oModelPAG:LoadValue("EK_PREFIXO",oModelPAU:GetValue("EK_PREFIXO"))
				oModelPAG:LoadValue("EK_TIPODOC",oModelPAU:GetValue("EK_TIPODOC"))
				oModelPAG:LoadValue("EK_TIPO"	,oModelPAU:GetValue("EK_TIPO"))
				oModelPAG:LoadValue("EK_MOEDA"	,oModelSOP:GetValue("MONEDA"))		
				oModelPAG:LoadValue("EK_NATUREZ",oModelPAU:GetValue("EK_NATUREZ"))
				oModelPAG:LoadValue("SINCHS"	,oModelPAU:GetValue("SINCHS"))
				oModelPAG:LoadValue("BAJACH"	,oModelPAU:GetValue("BAJACH"))

				If self:lFldDES
					oModelPAG:LoadValue("EK_DCONCEP",oModelPAU:GetValue("EK_DCONCEP"))
				EndIf

				nPag := VAL(oModelPAG:GetValue("EK_TIPODOC"))
				If oModelPAG:GetValue("SINCHS")
					nPag++
				EndIf

				jHdlPrv:FromJson(oModelEOP:GetValue("AHDLPRV"))
				If jHdlPrv['hdlprv'] <> Nil 
					oPGOEvent:aHdlPrv := jHdlPrv['hdlprv']
				EndIf

				If nPag <= 2
					oPGOEvent:F999GRVPGO(nPag, oModelPAG:GetValue("EK_TIPO"), oModelPAG:GetValue("EK_TIPO"),, oModel)
				Else
					oPGOEvent:F999GRVPGO(nPag, oModelPAG:GetValue("EK_TIPO"),, oModelPAG:GetValue("EK_TIPO"), oModel)
				EndIf

				FwFreeObj(oPGOEvent)
			EndIf
		Next
	EndIf

Return Nil

/*/{Protheus.doc} PMSFi999
	En caso de que la integraci�n con Totvs Obras y Proyectos este relacionada, llama a la pantalla de prorrateo de proyecto
	@type  Function
	@author carlos.espinoza
	@since 08/05/2026
	@version 12.1.2310 y superior
/*/
Static Function PMSFi999()
Local aArea
Local bPMSDlgF99 := {|| PmsDlgFI(3,SE2->E2_PREFIXO,SE2->E2_NUM,SE2->E2_PARCELA,SE2->E2_TIPO,SE2->E2_FORNECE,SE2->E2_LOJA)} //Ingteraci�n PMS
	
	aArea := GetArea()

	M->E2_NUM 		:= SE2->E2_NUM
	M->E2_PREFIXO   := SE2->E2_PREFIXO
	M->E2_FORNECE   := SE2->E2_FORNECE
	M->E2_LOJA		:= SE2->E2_LOJA
	M->E2_ORIGEM	:= SE2->E2_ORIGEM
	M->E2_VALOR		:= SE2->E2_VALOR
	M->E2_MOEDA		:= SE2->E2_MOEDA
	M->E2_TXMOEDA	:= SE2->E2_TXMOEDA

	Eval(bPMSDlgF99)
	PmsWriteFI(1,"SE2")
	RestArea(aArea)

Return

/*/{Protheus.doc} F999CmpMoe
	Funci�n recursiva para aplicar los valores recibidos en moneda diferente a los t�tulos en estos mismos t�tulos.
	@type  Function
	@author carlos.espinoza
	@since 08/05/2026
	@version 12.1.2310 y superior
	@param oModelSOP, Object, Modelo de Saldos de Ordenes de Pago
	@param oModelMOE, Object, Modelo de Monedas
/*/
Static Function F999CmpMoe(oModelSOP, oModelMOE)
Local nX 		:= 0
Local nI 		:= 0
Local nA 		:= 0
Local nP 		:= 0
Local nPago	    := 0
Local nJ 		:= 0
Local aTitPags 	:= {}
Local aOps    	:= {}

Default oModelSOP := Nil
Default oModelMOE := Nil

For nX := 1 To oModelSOP:Length()
	oModelSOP:GoLine(nX)
	If AScan(aOps,{|x| x == oModelSOP:GetValue("ORDPAGO")}) == 0
		AAdd(aOps, oModelSOP:GetValue("ORDPAGO"))
	EndIf
Next 

For nX := 1 To Len(aOps)
	For nI := 1 To oModelSOP:Length()
		oModelSOP:GoLine(nI)
		If oModelSOP:GetValue("ORDPAGO") == aOps[nX]
			AAdd(aTitPags, oModelSOP:GetValue("SALDO"))
		EndIf
	Next 

	For nA := 1 To Len(aTitPags)
		If aTitPags[nA]	> 0
			For nP := 1 To Len(aTitPags)
				If aTitPags[nA]	> 0
					If aTitPags[nP]	< 0
						nPago := Round(xMoeda(aTitPags[nP],nP,nA,,MsDecimais(nA)+1,oModelMOE:GetValue("TASA", nP),oModelMOE:GetValue("TASA", nA)),MsDecimais(nA))
						//El valor nPago es siempre negativo
						If Abs(nPago) > aTitPags[nA]
							aTitPags[nP] +=	Round(xMoeda(aTitPags[nA],nA,nP,,MsDecimais(nP)+1,oModelMOE:GetValue("TASA", nA),oModelMOE:GetValue("TASA", nP)),MsDecimais(nP))
							aTitPags[nA] :=	0
						ElseIf Abs(nPago) < aTitPags[nA]
							aTitPags[nA] +=	nPago
							aTitPags[nP] :=	0
						Else
							aTitPags[nA] :=	0
							aTitPags[nP] :=	0
						Endif
					Endif
				Else
					Exit
				Endif
			Next
		Endif
	Next

	For nI := 1 To oModelSOP:Length()
		oModelSOP:GoLine(nI)
		If oModelSOP:GetValue("ORDPAGO") == aOps[nX]
			nJ++
			If nJ <= Len(aTitPags)
				oModelSOP:LoadValue("SALDO", aTitPags[nJ])
			EndIf
		EndIf
	Next 

	nJ := 0
	aTitPags := {}
Next 

Return()

/*/{Protheus.doc} F999MODPA
	Funci�n que genera Pago Anticipado por Modalidad en uso del t�tulo financiero
	@type  Function
	@author carlos.espinoza
	@since 12/10/2026
	@version 12.1.2310 y superior
	@param oModel, Object, Modelo de Datos FINA999
/*/
Method F999MODPA(oModel) Class F999PA
Local oModelSE2 	:= oModel:GetModel('SE2_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local aArea			:= GetArea()
Local cNumVali		:= ""
Local nValor		:= 0
Local cImpAdi		:= ""
Local cTesSD2		:= ""
Local cQry 			:= ""
Local cParcSE2 		:= ""
Local nX 			:= 0
Local nLine 		:= 0
Local cNum 			:= ""
Local cPrefix 		:= ""
Local cFornc 		:= ""
Local cLoja 		:= ""
Local oExec         := Nil

	For nX := 1 To oModelFJR:Length()
		nLine := 0
		oModelFJR:GoLine(nX)

		If oModelFJR:GetValue("MARK") <> 1
			Loop
		EndIf

		//Grabado de T�tulos de Baja en la tabla SEK
		If !Empty(oModelFJR:GetValue("FJR_ORDPAG")) .And. oModelSE2:SeekLine({{"E2_ORDPAGO", oModelFJR:GetValue("FJR_ORDPAG")}}, .F., .T.)
			nLine := oModelSE2:GetLine()
			While nLine <= oModelSE2:Length() .And. oModelFJR:GetValue("FJR_ORDPAG") == oModelSE2:GetValue("E2_ORDPAGO")

				If POSICIONE("SED",1,self:cFilSED+oModelSE2:GetValue("E2_NATUREZ"),"ED_OPERADT") == "1"
					cNum 	:= oModelSE2:GetValue("E2_NUM")
					cPrefix := oModelSE2:GetValue("E2_PREFIXO")
					cFornc 	:= oModelSE2:GetValue("E2_FORNECE")
					cLoja 	:= oModelSE2:GetValue("E2_LOJA")

					DbSelectArea("SD1")
					SD1->(DbSetOrder(1)) //D1_FILIAL+D1_DOC+D1_SERIE+D1_FORNECE+D1_LOJA+D1_COD+D1_ITEM
					If SD1->(MsSeek(self:cFilSD1 + cNum + cPrefix + cFornc + cLoja,.F.))
						cTesSD2 := SD1->D1_TES
					EndIf

					DbSelectArea("SFC")
					SFC->(DbSetOrder(2)) //FC_FILIAL+FC_TES+FC_IMPOSTO
					If SFC->(MsSeek(self:cFilSFC + cTesSD2))
						cImpAdi  := SFC->FC_IMPOSTO
						cNumVali := POSICIONE("SFB", 1, self:cFilSFB + Padr(cImpAdi,self:nTamFBCod), "FB_CPOLVRO")
					EndIf

					If !Empty(cNum) .And. !Empty(cNumVali)
						DbSelectArea("SF1")
						SF1->(DbSetOrder(1)) //F1_FILIAL+F1_DOC+F1_SERIE+F1_FORNECE+F1_LOJA+F1_TIPO
						If SF1->(MsSeek(self:cFilSF1 + cNum + cPrefix + cFornc + cLoja))
							nValor 	 := &("SF1->F1_VALIMP" + cNumVali)
						EndIf
					EndIf

					cQry := "SELECT E2_PARCELA "
					cQry += "FROM " + RetSqlName("SE2") + " SE2 "
					cQry += "WHERE E2_PREFIXO = ? AND "
					cQry += "E2_NUM = ? AND "
					cQry += "E2_TIPO = ? AND "
					cQry += "E2_FORNECE = ? AND "
					cQry += "E2_LOJA = ? AND "
					cQry += "E2_FILIAL = ? AND "
					cQry += "D_E_L_E_T_ = ? " 
					cQry += "ORDER BY E2_PARCELA DESC " 
					cQry := ChangeQuery(cQry)

					oExec := FwExecStatement():New(cQry)
					oExec:SetString(1,cPrefix)
					oExec:SetString(2,cNum)
					oExec:SetString(3,self:cDocCred)
					oExec:SetString(4,cFornc)
					oExec:SetString(5,cLoja)
					oExec:SetString(6,self:cFilSE2)
					oExec:SetString(7,"")

					cParcSE2 := oExec:ExecScalar("E2_PARCELA") 

					If !Empty(cParcSE2)
						Soma1(cParcSE2)
					Else
						cParcSE2 := "1"
					EndIf

					oExec:Destroy()
					oExec := Nil

					RecLock("SE2",.T.)
					SE2->E2_FILIAL	:= self:cFilSE2
					SE2->E2_FILORIG := self:cFilSE2
					SE2->E2_NUMLIQ 	:= oModelFJR:GetValue("CLIQUID")
					SE2->E2_NUM    	:= cNum
					SE2->E2_PARCELA	:= cParcSE2
					SE2->E2_TIPO   	:= self:cDocCred
					SE2->E2_NATUREZ := oModelFJR:GetValue("FJR_NATURE")
					SE2->E2_FORNECE	:= oModelFJR:GetValue("FJR_FORNEC")
					SE2->E2_LOJA   	:= oModelFJR:GetValue("FJR_LOJA")
					SE2->E2_NOMFOR 	:= oModelFJR:GetValue("NOMBRE")
					SE2->E2_EMISSAO	:= dDataBase
					SE2->E2_EMIS1  	:= dDataBase
					SE2->E2_VENCTO 	:= dDataBase
					SE2->E2_VENCORI	:= dDataBase
					SE2->E2_VENCREA	:= DataValida(dDataBase,.T.)
					If self:lPERGenPA .And. AllTrim(self:cDocCred) == "PA" //Valida Generacion de PA en PER
						SE2->E2_VALOR 	:= Abs(SF1->F1_VALMERC)
						SE2->E2_SALDO  	:= SF1->F1_VALMERC
						SE2->E2_VLCRUZ 	:= Round(xMoeda(Abs(SF1->F1_VALMERC),oModelSE2:GetValue("E2_MOEDA"),1,,5,oModelSE2:GetValue("E2_TXMOEDA")), MsDecimais(1))
					Else
						SE2->E2_VALOR 	:= Abs(oModelSE2:GetValue("E2_PAGAR"))
						SE2->E2_SALDO  	:= oModelSE2:GetValue("E2_PAGAR") - nValor
						SE2->E2_VLCRUZ 	:= Round(xMoeda(Abs(oModelSE2:GetValue("E2_PAGAR")),oModelSE2:GetValue("E2_MOEDA"),1,,5,oModelMOE:GetValue("TASA",1)),MsDecimais(1))
					EndIf
					SE2->E2_MOEDA  	:= oModelSE2:GetValue("E2_MOEDA")
					SE2->E2_PREFIXO	:= cPrefix
					SE2->E2_SITUACA	:= "0"
					SE2->E2_ORDPAGO	:= oModelFJR:GetValue("FJR_ORDPAG")
					SE2->E2_ORIGEM 	:= "FINA085A"

					If oModelSE2:HasField("E2_TXMOEDA")
						If self:lPERGenPA
							SE2->E2_TXMOEDA := oModelSE2:GetValue("E2_TXMOEDA")
						Else
							SE2->E2_TXMOEDA := oModelMOE:GetValue("TASA",1)
						EndIf
					EndIf

					DbSelectArea("SA2")
					SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
					SA2->(MsSeek(self:cFilSA2+oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")))

					IF Empty(oModelFJR:GetValue("FJR_NATURE"))
						If Empty(SA2->A2_NATUREZ)
							SE2->E2_NATUREZ	:= self:cNature
						Else
							SE2->E2_NATUREZ	:= SA2->A2_NATUREZ
						EndIf
					EndIf

					If oModelSE2:HasField("E2_CGC")
						SE2->E2_CGC	:= SA2->A2_CGC
					EndIf

					If !self:lUsaFlag
						SE2->E2_LA  := "S"
					EndIf

					SE2->(MsUnlock())

				EndIf
				
				nLine++
				If nLine <= oModelSE2:Length()
					oModelSE2:GoLine(nLine)
				EndIf
			EndDo
		EndIf
	Next

	RestArea(aArea)

Return Nil
