#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} FINV999
	Clase responsable por el evento de reglas de negocio de localizaci�n padr�n
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class FINV999 From FwModelEvent 
    
    DATA lVldMod   As Logical

    DATA lVldLin   As Logical

    DATA lCkPg     As Logical

	Method New() CONSTRUCTOR
	
	Method VldActivate()
	
	Method ModelPosVld()
	
	Method GridLinePosVld()

	Method AfterTTS()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class FINV999
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method VldActivate(oModel) Class FINV999
Local lRet			:= .T.

	self:lVldMod 	:= .F.

	self:lVldLin 	:= .T.

	self:lCkPg 		:= .F.

Return lRet

/*/{Protheus.doc} ModelPosVld
	M�todo responsable por ejecutar las valida�ioes de las reglas de negocio
	gen�ricas del cadastro antes de la grabaci�n del formulario.
	Si retorna falso, no permite grabar.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param 		oModel, Object, Modelo de dados
	@param 		cModelID, Character, Identificador do sub-modelo
	@return     Logical, Indica si las validaciones fueron satisfactorias
/*/
Method ModelPosVld(oModel,cModelID) Class FINV999
Local lRet 			:= .T. As Logical
Local nOperation	:= oModel:GetOperation() As Numeric
Local nX			:= 0 As Numeric
Local oModelEOP		:= oModel:GetModel("EOP_MASTER") As Object
Local oModelFJR		:= oModel:GetModel("FJR_MASTER") As Object
Local oModelPAG		:= oModel:GetModel("PAG_DETAIL") As Object
Local lPa085a		:= IsInCallStack("A085APgAdi")

	If nOperation == MODEL_OPERATION_INSERT

		If lRet .And. oModelEOP:GetValue("NNUMORDENS") < 0
			Help("",1,"SEMORDPAG")
			lRet := .F.
		EndIf

		If lRet
			For nX := 1 To oModelFJR:Length()
				If lRet .And. oModelFJR:GetValue("NVLRPAGAR",nX) < 0
					Help(,,STR0040,,STR0055,1, 0 ) //"Aviso" - "El valor a pagar de la orden de pago no puede ser negativo."
					lRet := .F.
					Exit
				EndIf
				
				//Verifica la naturaleza informada en las ordenes de pago
				If lRet .And. !lPa085a .And. (self:lVldMod .Or. oModelFJR:GetValue("NVLRPAGAR",nX) <> 0) .And. !F999VldNat(oModelFJR:GetValue("FJR_NATURE",nX))
					lRet := .F.
					Exit
				EndIf
			Next 
		EndIf

		If lRet
			For nX := 1 To oModelPAG:Length()
				//Verifica que la forma de pago o este vac�a cuando el valor a sido informado
				If lRet .And. !Empty(oModelPAG:GetValue("EK_VALOR",nX)) .And. Empty(oModelPAG:GetValue("EK_TIPO",nX))
					Help(,,STR0040,,STR0041,1, 0 ) //"Aviso" - "Hay �tems que no tienen la forma de pago definida"
					lRet := .F.
				EndIf
			Next
		EndIf	

		If lRet .And. oModelEOP:GetValue("PA")
			If oModelFJR:GetValue("TOTAL") < 0
				Help(" ",1,"VALNEG")
				lRet := .F.
			EndIf

			If lRet .And. !F999VlProv(oModelFJR:GetValue("FJR_FORNEC"), oModelFJR:GetValue("FJR_LOJA"))
				Help(" ",1,"NOFORNEC")
				lRet := .F.
			EndIf

			If lRet .And. oModelEOP:GetValue("NPAGAR") <> 3 .And. oModelEOP:GetValue("NPAGAR") > 0 .And. oModelPAG:GetValue("EK_BANCO") $ SuperGetMV("MV_CARTEIR")
				Help("",1,"a085ChqCar")
				lRet := .F.
			EndIf
		EndIf
	EndIf

Return lRet

/*/{Protheus.doc} GridLinePosVld
	Metodo responsabe por ejecutar reglas de negocio genericas para validaci�n de l�nea.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param 		oModel, Object, Modelo de dados
	@param 		cModelID, Character, Identificador do sub-modelo
	@param 		nLine, Numeric, N�mero de l�nea validada
	@return     Logical, Indica si las validaciones fueron satisfactorias
/*/
Method GridLinePosVld(oSubModel, cModelID, nLine) Class FINV999
Local lRet		 := .T. As Logical
Local nX   		 := 0 As Numeric
Local nOperation := oSubModel:GetOperation() As Numeric
Local aArea		 := {}
Local cChaveSE2  := ""

	If nOperation == MODEL_OPERATION_INSERT
		If cModelID == "PAG_DETAIL"
			If self:lVldLin .And. IsInCallStack("A085ALNOK")
				If lRet .And. (Empty(oSubModel:GetValue("EK_BANCO")) .Or. Empty(oSubModel:GetValue("EK_AGENCIA")) .Or. Empty(oSubModel:GetValue("EK_CONTA"))) ;
					.And. oSubModel:GetValue("EK_TIPODOC") <> "3"
					Help(,,STR0040,,STR0054,1, 0 ) // "Aviso" - "El banco es obligatorio para d�bitos mediatos e inmediatos."
					lRet	:=	.F.
				EndIf

				If lRet .And. Alltrim(oSubModel:GetValue("EK_TIPODOC")) == "2" .And. oSubModel:GetValue("EK_VENCTO") <> dDataBase
					Help(" ",1,"BLOQDTVENC")
					lRet	:=	.F.
				EndIf

				If lRet
					For nX := 1 To oSubModel:Length()
						If nX <> nLine .And. oSubModel:GetValue("EK_TIPO", nX) + oSubModel:GetValue("EK_TIPODOC", nX) +;
						oSubModel:GetValue("EK_NUM", nX) + oSubModel:GetValue("EK_PARCELA", nX) == ;
						oSubModel:GetValue("EK_TIPO", nLine) + oSubModel:GetValue("EK_TIPODOC", nLine) +;
						oSubModel:GetValue("EK_NUM", nLine) + oSubModel:GetValue("EK_PARCELA", nLine)
							Help(" ",1,"FA050NUM")
							lRet	:=	.F.
							Exit
						Endif
					Next
				EndIf

				If lRet
					aArea := SE2->(GetArea())
					cChaveSE2 := xFilial("SE2")+Space(GetSx3Cache("E2_PREFIXO","X3_TAMANHO"))+oSubModel:GetValue("EK_NUM")+oSubModel:GetValue("EK_PARCELA")+oSubModel:GetValue("EK_TIPO")
					DbSelectArea("SE2")
					SE2->(DbSetOrder(1)) //E2_FILIAL+E2_PREFIXO+E2_NUM+E2_PARCELA+E2_TIPO+E2_FORNECE+E2_LOJA
					If SE2->(MsSeek(cChaveSE2))
						While lRet .And. !SE2->(EOF()) .And. cChaveSE2 == xFilial("SE2")+SE2->E2_PREFIXO+SE2->E2_NUM+SE2->E2_PARCELA+SE2->E2_TIPO
							If SE2->E2_BCOCHQ == oSubModel:GetValue("EK_BANCO") .And. SE2->E2_AGECHQ == oSubModel:GetValue("EK_AGENCIA") .And. SE2->E2_CTACHQ == oSubModel:GetValue("EK_CONTA")
								Help(" ",1,"CHEQJAEXIST")
								lRet :=	.F.
							EndIf
							SE2->(DbSkip())
						EndDo
					Endif
					RestArea(aArea)
				EndIf

				If lRet .And. self:lCkPg .And. !F999CkPG(oSubModel:GetValue("EK_BANCO"),Alltrim(oSubModel:GetValue("EK_TIPO")),Alltrim(oSubModel:GetValue("EK_TIPODOC")))
					lRet :=	.F.
				EndIf
			EndIf
		EndIf
	EndIf

Return lRet

/*/{Protheus.doc} F999VldNat
	Funci�n que valida la naturaleza de la orden de pago
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		08/08/2025
	@param 		cNatureza, Character, C�digo de la naturaleza de la orden de pago
	@return		Logical, Indica si la naturaleza es correcta
/*/
Function F999VldNat(cNatureza)

Local lRet 		:= .T.
Local cNatAux 	:= ""
Local aArea		:= {}

Default cNatureza := ""

		If lRet
			//Verifica si existe la naturaleza en la tabla SED
			cNatAux := Padr(cNatureza,GetSx3Cache("ED_CODIGO","X3_TAMANHO"))
			aArea := SED->(GetArea())
			DbSelectArea("SED")
			SED->(DbSetOrder(1)) //ED_FILIAL+ED_CODIGO
			If !SED->(MsSeek(xFilial("SED")+cNatAux))
				Help(,,STR0040,,STR0043,1, 0 ) //"Aviso" - "La modalidad seleccionada no existe."
				lRet := .F.
			EndIf
			RestArea(aArea)
		EndIf

		If lRet .And. !FinVldNat( .F., cNatAux)
			lRet := .F.
		EndIf

Return lRet

/*/{Protheus.doc} F999VldDes
	Funci�n que valida el descuento de la orden de pago
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		08/08/2025
	@param 		nDesc, Numeric, Descuento de la orden de pago
	@param		nPorDesc, Character, Porcentaje de descuento de la orden de pago
	@return		Logical, Indica si los descuentos son correctos
/*/
Function F999VldDes(nDesc, nPorDesc)

Local lRet 		:= .T.

Default nDesc 	 := 0
Default nPorDesc := 0

		If nDesc < 0 .Or. nPorDesc < 0
			Help(,,STR0040,,STR0042,1, 0 ) //"Aviso" - "Introduzca un valor de descuento mayor o igual que cero."
			lRet := .F.
		EndIf

Return lRet

/*/{Protheus.doc} F999CkPG
	Funci�n que valida si el banco recibe asiento dependiendo del tipo de d�bito y la forma de pago
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/10/2025
	@param 		cBanco, Character, C�digo de Banco
	@param 		cDebInm, Character, Tipo de forma de pago
	@param 		cPagar, Character, Tipo de d�bito
	@param 		lVldBco, Logical, Indica si debe validar el banco
	@return 	Logical, Indica si las validaciones fueron satisfactorias
/*/
Function F999CkPG(cBanco, cDebInm, cPagar, lVldBco)

Local lRet 		 := .T.
Local lF85ABCVLD := ExistBlock("F85ABCVLD")
Local cCxFin	 := Left(SuperGetMv("MV_CXFIN"),GetSx3Cache("A6_COD","X3_TAMANHO")) + "/" + SuperGetMv("MV_CARTEIR")

Default cBanco 	 := ""
Default cDebInm  := ""
Default cPagar	 := ""
Default lVldBco  := .F.

	If !lF85ABCVLD
		If !Empty(cBanco) .And. cBanco $ cCxFin .Or. IsCaixaLoja(cBanco)
			If cPagar == "2" .And. cDebInm == "TF"
				Help(,,STR0040,,STR0058+cBanco+STR0059,1, 0) //"Aviso" - "El Banco # no recibe asientos del tipo TF."
				lRet := .F.
			Elseif cPagar == "1" .Or. cPagar == "2"
				Help(,,STR0040,,STR0058+cBanco+STR0060,1, 0) //"Aviso" - "El Banco # no recibe asientos del tipo CH."
				lRet := .F.
			Endif

			If lVldBco
				lRet := .F.
			EndIf
		Endif
	Else
		lRet := ExecBlock("F85ABCVLD",.F.,.F.,{cDebInm,cBanco,Val(cPagar)})
	EndIf
	
Return lRet

/*/{Protheus.doc} F999VlProv
	Funci�n que valida si el proveedor/tienda informado es v�lido
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		05/11/2025
	@param		cProveedor, Character, C�digo del proveedor
	@param		cLoja, Character, Tienda del proveedor
	@return		Logical, Indica si el proveedor/tienda es correcto
/*/
Function F999VlProv(cProveedor, cLoja)

Local lRet 		:= .T.
Local aArea		:= {}

Default cProveedor := ""
Default cLoja	   := ""

	aArea := SA2->(GetArea())
	SA2->(DbsetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
	If !SA2->(MsSeek(xFilial("SA2")+cProveedor+cLoja))
		lRet := .F.
	EndIf
	RestArea(aArea)

Return lRet

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio genericas 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		06/12/2025 
	@param 		oModel, Object, Modelo de dados de Clientes.
	@param 		cModelId, Character, Identificador do sub-modelo.
/*/
Method AfterTTS(oModel, cModelId) Class FINV999
Local nOperation	:= oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT
		If __lSX8
			ConfirmSX8()
		Endif
	EndIf

Return Nil

/*/{Protheus.doc} F999ActSal
	Funci�n que actualiza el saldo de una orden de pago en una moneda en espec�fico
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		11/05/2026
	@param		oModelSOP, Object, Modelo de saldos de cada orden de pago
	@param		cOrdPgo, Character, Orden de pago
	@param		nMoneda, Numeric, Moneda
	@param		nValor, Numeric, Valor
	@param		lSum, Logical, Indica si se debe sumar o restar el valor
/*/
Function F999ActSal(oModelSOP, cOrdPgo, nMoneda, nValor, lSum)

Default oModelSOP := Nil
Default cOrdPgo   := ""
Default nMoneda   := 0
Default nValor    := 0
Default lSum      := .F.

	If oModelSOP:SeekLine({{"ORDPAGO", cOrdPgo},{"MONEDA", nMoneda}}, .F., .T.)
		If lSum
			oModelSOP:LoadValue("SALDO", oModelSOP:GetValue("SALDO") + nValor)
		Else
			oModelSOP:LoadValue("SALDO", oModelSOP:GetValue("SALDO") - nValor)
		EndIf
	EndIf
	
Return Nil

/*/{Protheus.doc} F999TxMon
	Asignar la tasa de cambio original (tasa del t�tulo) o la informada en la rutina de orden de pago.
	@type Function
	@author  carlos.espinoza
	@since   06/12/2025
	@version 1.0
	@param	 nMoeda, Numeric, Moneda del t�tulo.
	@param	 nTxOrig, Numeric, Tasa de cambio del t�tulo.
	@param	 nTxMoeda, Numeric, Tasa de cambio del d�a/informada.
	@param	 oJCotiz, Object, Objeto que contiene la cotizaci�n del t�tulo
	@return  Numeric, Tasa de cambio.
/*/
Function F999TxMon(nMoeda, nTxOrig, nTxMoeda, oJCotiz)
Local nTsCamb := 1

Default nMoeda   := 0
Default nTxOrig  := 0
Default nTxMoeda := 0
Default oJCotiz  := JsonObject():New()

	If oJCotiz['TipoCotiz'] == 2 .And. nMoeda > 1
		nTsCamb := nTxOrig
	Else
		nTsCamb := nTxMoeda
	EndIf

Return nTsCamb

/*/{Protheus.doc} F999fTxMoe
	Obtiene las tasas de cambio para la fecha de emisi�n del documento
	@type Function
	@author  carlos.espinoza
	@since   06/12/2025
	@version 1.0
	@param		dEmision, Date, Fecha de emisi�n del documento.
	@param		oModelMOE, Object, Modelo de monedas
	@param		oJCotiz, Object, Objeto que contiene la cotizaci�n del t�tulo
	@return 	Array, Array con las tasas de cambio.
/*/
Function F999fTxMoe(dEmision, oModelMOE, oJCotiz)
Local nX 		:= 0
Local cEmision  := ""
Local aTasaCamb := {}

Default dEmision  := CTOD("//")
Default oModelMOE := Nil
Default oJCotiz   := JsonObject():New()

	cEmision := DTOC(dEmision)
	If !oJCotiz:HasProperty(cEmision)
		oJCotiz[cEmision] := {}
		For nX := 1 To oModelMOE:Length()
			aAdd(aTasaCamb, RecMoeda(dEmision, nX))
		Next
		oJCotiz[cEmision] := aClone(aTasaCamb)
	Else
		aTasaCamb := aClone(oJCotiz[cEmision])
	EndIf

Return aClone(aTasaCamb)

/*/{Protheus.doc} F999GrvTx
	Graba tasas de la moneda en la tabla SEK en caso de existir campos de tasas
	@type Function
	@author  carlos.espinoza
	@since   06/12/2025
	@version 1.0
	@param	nMoedaCot, Numeric, Moneda cotizaci�n
	@param	nTxMoeda, Numeric, Tasa de cambio del d�a/informada.
	@param	aTxEmis, Array, Tasas del t�tulo
	@param	oJCotiz, Object, Objeto que contiene la cotizaci�n del t�tulo
	@param	oModelMOE, Object, Modelo de monedas
	@param	oModelTTB, Object, Modelo de Titulos de Baja
/*/
Function F999GrvTx(nMoedaCot, nTxMoeda, aTxEmis, oJCotiz, oModelMOE, oModelTTB, lSEK)
Local nTx := 0

Default nMoedaCot := 1
Default nTxMoeda  := 1
Default aTxEmis   := {}
Default oJCotiz   := JsonObject():New()
Default oModelMOE := Nil
Default oModelTTB := Nil
Default lSEK 	  := .F.

	If oJCotiz['lCpoCotiz'] .And. oJCotiz['TipoCotiz'] == 2 .And. Len(aTxEmis) > 0
		For nTx := 2 To Len(aTxEmis)
			If nMoedaCot <> nTx
				If !lSEK
					oModelTTB:LoadValue("EK_TXMOE" + StrZero(nTx,2), aTxEmis[nTx])
				Else
					SEK->&("EK_TXMOE" + StrZero(nTx,2)) := aTxEmis[nTx]
				EndIf
			ElseIf nMoedaCot == nTx
				If nMoedaCot > 1 .And. nTxMoeda > 0
					If !lSEK
						oModelTTB:LoadValue("EK_TXMOE" + StrZero(nMoedaCot,2), nTxMoeda)
					Else
						SEK->&("EK_TXMOE" + StrZero(nMoedaCot,2)) := nTxMoeda
					EndIf
				EndIf
			EndIf
		Next nTx
		If !lSEK
			oModelTTB:LoadValue("EK_TXCOTIZ", nTxMoeda)
		Else
			SEK->EK_TXCOTIZ := nTxMoeda
		EndIf
	Else
		If !lSEK
			For nTx := 2 To oModelMOE:Length()
				oModelMOE:GoLine(nTx)
				If oModelTTB:HasField("EK_TXMOE"+StrZero(nTx,2))
					oModelTTB:LoadValue("EK_TXMOE"+StrZero(nTx,2),oModelMOE:GetValue("TASA"))
				Endif
			Next nTx
		Else
			For nTx := 2 To oModelMOE:Length()
				oModelMOE:GoLine(nTx)
				If (SEK->(ColumnPos("EK_TXMOE"+StrZero(nTx,2))) > 0)
					SEK->&("EK_TXMOE"+StrZero(nTx,2)) := oModelMOE:GetValue("TASA")
				Endif
			Next nTx
		EndIf
	EndIf

Return NIL

/*/{Protheus.doc} F999GrvTx
	Graba la tasa de cambio promedio en la tabla de retenciones
	@type Function
	@author carlos.espinoza
	@since 16/04/2026
	@version 1.0
	@param	nTxPromed, Numeric, Tasa de cambio.
	@param	oJCotiz, Object, Objeto que contiene la cotizaci�n del t�tulo
	@param	oModelSFE, Object, Modelo de retenciones
/*/
Function F999TxSFE(nTxPromed, oJCotiz, oModelSFE)

Default nTxPromed := 1
Default oJCotiz   := Nil
Default oModelSFE := Nil

	If oJCotiz['lCpoCotiz'] .And. nTxPromed > 0
		oModelSFE:LoadValue("FE_TXCOTIZ", nTxPromed)
	EndIf

Return

/*/{Protheus.doc} F999PERet
	Ejecuta punto de entrada de retenciones con posicionamientos en las tabla SFE y SEK
	@type Function
	@author carlos.espinoza
	@since 15/09/2026
	@version 1.0
	@param	oModelSFE, Object, Modelo de retenciones.
	@param	oJImp, Object, Objeto de Impuestos
	@param	cPE, Character, Punto de Entrada
/*/
Function F999PERet(oModelSFE, oJImp, cPE)
Local cTamPref		:= ""
Local cTamParc		:= ""
Local nTamNum		:= 0
Local cNumCrt		:= ""
Local aArea 		:= GetArea()
Local cFilSEK		:= xFilial("SEK")
Local cFilSFE		:= xFilial("SFE")
Local nX			:= 0

Default oModelSFE 	:= Nil
Default oJImp 		:= Nil
Default cPE 		:= ""

	cTamPref   := PadR("", GetSx3Cache("EK_PREFIXO", "X3_TAMANHO"))
	cTamParc   := PadR("", GetSx3Cache("EK_PARCELA", "X3_TAMANHO"))
	nTamNum    := GetSx3Cache("EK_NUM", "X3_TAMANHO")

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		DbSelectArea("SFE")
		SFE->(DbSetOrder(9)) //FE_FILIAL+FE_NROCERT+FE_TIPO
		SFE->(MsSeek(cFilSFE+oModelSFE:GetValue("FE_NROCERT")+oModelSFE:GetValue("FE_TIPO")))
		While !SFE->(EOF()) .And. SFE->FE_FILIAL == oModelSFE:GetValue("FE_FILIAL"); 
							.And. SFE->FE_NROCERT == oModelSFE:GetValue("FE_NROCERT");
							.And. SFE->FE_TIPO == oModelSFE:GetValue("FE_TIPO")

			If SFE->FE_ORDPAGO == oModelSFE:GetValue("FE_ORDPAGO")
				cNumCrt := StrZero(Val(oModelSFE:GetValue("FE_NROCERT")),nTamNum)
				DbSelectArea("SEK")
				SEK->(DbSetOrder(1)) //EK_FILIAL+EK_ORDPAGO+EK_TIPODOC+EK_PREFIXO+EK_NUM+EK_PARCELA+EK_TIPO+EK_SEQ
				If SEK->(MsSeek(cFilSEK+oModelSFE:GetValue("FE_ORDPAGO")+"RG"+cTamPref+cNumCrt+cTamParc+oJImp[Alltrim(SFE->FE_TIPO)][1]))
					ExecBlock(cPE,.F.,.F.,oJImp[SFE->FE_TIPO][2])
					Exit
				EndIf
			EndIf
			SFE->(DbSkip())
		EndDo
	Next

	RestArea(aArea)

Return Nil
