#Include 'Protheus.ch'
#Include 'FWMVCDef.ch'

PUBLISH MODEL REST NAME FINA010PAR source FINA010PAR RESOURCE OBJECT FsmRestModel

#DEFINE SOURCEFATHER "FINA010"

//-------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} FINA010PAR
Cadastro de Natureza localizado para PARAGUAI.

O fonte cont�m browse, menu, model e view propria, todos herdados do FINA010. 
Qualquer regra que se aplique somente para o PARAGUAI deve ser definida aqui.

As valida��es e integra��es realizadas ap�s/durante a grava��o est�o definidas nos eventos do modelo, 
na classe FINA010EVPAR.

@type function
 
@author Alan Lunardi
@since 30/03/2025
@version P12.1.2410
/*/
//-------------------------------------------------------------------------------------------------------------
Function FINA010PAR()
Local oBrowse As Object
	
	oBrowse := BrowseDef()
	
	oBrowse:Activate()
	
Return nil
//-------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} BrowseDef
Define o browse padr�o para o cadastro de natureza.

@type function
 
@author Alan Lunardi
@since 30/03/2025
@version P12.1.2410
/*/
//-------------------------------------------------------------------------------------------------------------
Static Function BrowseDef()
Local oBrowse As Object 
	
	oBrowse := FwLoadBrw(SOURCEFATHER) 

Return oBrowse
//-------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} ModelDef
Define o model padr�o para o cadastro de natureza.

@type function
 
@author Alan Lunardi
@since 30/03/2025
@version P12.1.2410
/*/
//-------------------------------------------------------------------------------------------------------------
Static Function ModelDef()
Local oModel As Object
Local oEvent As Object
	
	oModel := FWLoadModel(SOURCEFATHER)
	oEvent := FINA010EVPAR():New()
	oModel:InstallEvent("PARAGUAI",,oEvent)
	
Return oModel
//-------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} ViewDef
Define a view padr�o para o cadastro de natureza.

@type function
 
@author Alan Lunardi
@since 30/03/2025
@version P12.1.2410
/*/
//-------------------------------------------------------------------------------------------------------------
Static Function ViewDef()
Local oView As Object

	oView := FWLoadView(SOURCEFATHER)

Return oView

//-------------------------------------------------------------------------------------------------------------
/*/{Protheus.doc} MenuDef
Define o menu padr�o para o cadastro de natureza.

@type function
 
@author Alan Lunardi
@since 30/03/2025
@version P12.1.2410
/*/
//-------------------------------------------------------------------------------------------------------------
Static Function MenuDef()
Local aRotina	As Array 

	aRotina  := FWLoadMenuDef(SOURCEFATHER)

	
Return aRotina
