#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} F999PGO
	Clase responsable por el evento de reglas de negocio referente al proceso formas de pago
	@type 		Class
	@author 	Jose.Gonzalez
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999PGO From FwModelEvent 

	DATA lMarkLa	As Logical

	DATA lPag1	    As Logical

	DATA lElt	    As Logical

	DATA lCBU	    As Logical

	DATA lTalao	    As Logical

	DATA lBxE2	    As Logical

	DATA lNat	    As Logical

	DATA lDesc	    As Logical

	DATA lCgc	    As Logical

	DATA lDtLib	    As Logical

	DATA cLog	    As Character

	DATA cMsj	    As Character

	DATA lF999NUM	As Logical

	DATA lF999PRECH	As Logical

	DATA lF999GRA	As Logical

	DATA lF999PAG	As Logical

	DATA cF999NUM	As Character

	DATA cF999PRECH	As Character

	DATA cF999GRA	As Character

	DATA cF999PAG	As Character

	DATA cLibCheq	As Character

	DATA nMVCusto	As Numeric

	DATA lF999DOC3	As Logical

	DATA lVldCh		As Logical

	DATA lCalcITF	As Logical

	DATA lFindITF	As Logical

	DATA lAjusITF	As Logical

	DATA c1Dup		As Character

	DATA cDebInm	As Character

	DATA cDebMed	As Character

	DATA aHdlPrv	As Array

	DATA oModBxE2   As Object

	DATA oFKABxE2   As Object

	DATA oFK2BxE2   As Object

	DATA oModBxE1   As Object

	DATA oFKABxE1   As Object

	DATA oFK1BxE1   As Object

	DATA oModMovBco As Object

	DATA oFKAMovBco As Object

	DATA oFK5MovBco As Object

	Method New() CONSTRUCTOR

	Method VldActivate()

	Method InTTS()

	Method AfterTTS()

	Method F999GRVMDL()

	Method F999GRVTB()

	Method F999GRVPGO()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	Jose.Gonzalez
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999PGO
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	Jose.Gonzalez
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param      oModel, Object, Modelo de dados
/*/
Method VldActivate(oModel) Class F999PGO
Local lRet			:= .T.
Local lModII		:= IsInCallStack("FINA850")

	self:lPag1		:= .F.

	self:lElt		:= .F.

	self:lCBU		:= .F.

	self:lTalao		:= .F.

	self:lBxE2		:= .F.

	self:lVldCh     := .T.

	self:lCalcITF   := .T.

	self:lAjusITF   := .F.

	self:lMarkLa    := .F.

	self:cLibCheq	:= SuperGetMV("MV_LIBCHEQ", .F., "")

	self:nMVCusto	:= Val(SuperGetMV("MV_MCUSTO", .F., ""))

	self:lF999DOC3	:= ExistBlock("F850DOC3")

	self:lNat		:= SEK->(ColumnPos("EK_NATUREZ")) > 0

	self:lDesc		:= SEK->(ColumnPos("EK_DCONCEP")) > 0

	self:lCgc		:= SE2->(ColumnPos("E2_CGC")) > 0

	self:lDtLib		:= SE2->(ColumnPos("E2_DATALIB")) > 0

	self:c1Dup      := SuperGetMV("MV_1DUP",.F.,"")

	self:lFindITF   := FindFunction("FinProcITF")

	self:aHdlPrv    := {}

	If lModII
		self:lF999NUM	:= ExistBlock("A850NUM")

		self:lF999PRECH	:= ExistBlock("A850PRECH")

		self:lF999GRA	:= ExistBlock("F850GRA")

		self:lF999PAG	:= ExistBlock("A850PAG")

		self:cF999NUM	:= "A850NUM"

		self:cF999PRECH	:= "A850PRECH"

		self:cF999GRA	:= "F850GRA"

		self:cF999PAG	:= "A850PAG"
	Else
		self:lF999NUM	:= ExistBlock("A085ANUM")

		self:lF999PRECH	:= ExistBlock("A085PRECH")

		self:lF999GRA	:= ExistBlock("F085GRA")

		self:lF999PAG	:= ExistBlock("A085APAG")

		self:cF999NUM	:= "A085ANUM"

		self:cF999PRECH	:= "A085PRECH"

		self:cF999GRA	:= "F085GRA"

		self:cF999PAG	:= "A085APAG"

		self:cDebMed    := GetSESTipos({|| ES_RCOPGER == "1"},"2")

		self:cDebInm    := GetSESTipos({|| ES_RCOPGER == "2"},"2")

		If Empty(self:cDebMed)
			self:cDebMed := MVCHEQUE
		EndIf

		If Empty(self:cDebInm)
			self:cDebInm := "TF|EF"
		EndIf

	EndIf
	
Return lRet

/*/{Protheus.doc} InTTS
	Metodo responsable por ejecutar reglas de negocio genericas 
	dentro de la transacci�n del modelo de datos.
	@type 		Method
	@author 	Jose.Gonzalez
	@version	12.1.2310 / Superior
	@since		13/11/2025 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, IdentIficador do sub-modelo
/*/
Method InTTS(oModel, cModelId) Class F999PGO
Local nOperation	:= oModel:GetOperation()
Local oModelEOP  	:= oModel:GetModel('EOP_MASTER')

	If nOperation == MODEL_OPERATION_INSERT .And. !oModelEOP:GetValue("HASERROR")
		Begin Transaction
			self:cLog := ""
			If !self:F999GRVMDL(oModel)
				DisarmTransaction()
				oModelEOP:SetValue("HASERROR", .T.)
			EndIf
		End Transaction
	EndIf

Return Nil

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio de retenciones 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		03/06/2026 
	@param      oModel, Object, Modelo de dados
/*/
Method AfterTTS(oModel) Class F999PGO
Local nOperation := oModel:GetOperation()
Local lVldRet    := Type("lF999Ret") == "L"

	If nOperation == MODEL_OPERATION_INSERT 
		If !Empty(self:cLog) .And. !Empty(self:cMsj)
			Help(,,self:cMsj,,self:cLog, 1, 0)
			If lVldRet
				lF999Ret := .F.
			EndIf
		EndIf
	EndIf

Return Nil

/*/{Protheus.doc} F999GRVMDL
	Metodo responsable por realizar las actualizaciones de las tablas por el modelo FINA999
	@type 		Method
	@author 	Jose.Gonzalez
	@version	12.1.2310 / Superior
	@since		13/11/2025 
	@param      oModel, Object, Modelo de dados
/*/
Method F999GRVMDL(oModel) Class F999PGO
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelPAG 	:= oModel:GetModel('PAG_DETAIL')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local oModel3RO		:= oModel:GetModel('3RO_DETAIL')
Local lRet			:= .T.
Local nX 			:= 0
Local nLine 		:= 0
Local aFormasPgto   := Fin025Tipo() 
Local nPosPgto		:= 0
Local cFilSA2   	:= xFilial("SA2")
Local cFilSE1		:= xFilial("SE1")
Local cFilSEF		:= xFilial("SEF")
Local cPrefix       := ""
Local cNum			:= ""
Local cParcela      := ""
Local cTipoDoc      := ""
Local aAreaSA2      := {}
Local aAreaSE1      := {}
Local aAreaSEF      := {}
Local nPag          := 0
Local cDebitoM		:= ""
Local cDebitoI		:= ""
Local cHdlPrv   	:= ""
Local jHdlPrv		:= JsonObject():New()

	If self:lCalcITF .And. self:lFindITF .And. VerPadrao("570")
		cHdlPrv := oModelEOP:GetValue("AHDLPRV")
		jHdlPrv:FromJson(cHdlPrv)
		If jHdlPrv['hdlprv'] <> Nil 
			self:aHdlPrv  := jHdlPrv['hdlprv']
		EndIf
	EndIf

	For nX := 1 To oModelFJR:Length()
		nLine := 0
		oModelFJR:GoLine(nX)

		If oModelFJR:GetValue("MARK") <> 1
			Loop
		EndIf

		//Grabado de Documentos propios
		If !Empty(oModelFJR:GetValue("FJR_ORDPAG")) .And. oModelPAG:SeekLine({{"EK_ORDPAGO", oModelFJR:GetValue("FJR_ORDPAG")}}, .F., .T.) 
			nLine := oModelPAG:GetLine()
			While nLine <= oModelPAG:Length() .And. oModelFJR:GetValue("FJR_ORDPAG") == oModelPAG:GetValue("EK_ORDPAGO");
				.And. !Empty(oModelPAG:GetValue("EK_TIPO"))

				If oModelEOP:GetValue("MODII")

					//Uso de la tabla FJS para ver configuraci�n de formas de pago
					nPosPgto := Ascan(aFormasPgto, {|x| AllTrim(x[1]) == AllTrim(oModelPAG:GetValue("EK_TIPO"))})
					
					If nPosPgto > 0 
						If aFormasPgto[nPosPgto,4] == "1"   	 // D�bito Mediato
							lRet := self:F999GRVPGO(2, aFormasPgto[nPosPgto,1], aFormasPgto[nPosPgto,2],, oModel)
						ElseIf aFormasPgto[nPosPgto,4] == "2"    // D�bito Inmediato	
							lRet := self:F999GRVPGO(3, aFormasPgto[nPosPgto,1],, aFormasPgto[nPosPgto,2], oModel)	
						EndIf

						If oModelEOP:GetValue("CPGTOELT") <> "1" .Or. oModelEOP:GetValue("PA")  
							If oModelFJR:GetValue("NMOERET") <> 1 .And. oModelEOP:GetValue("PA")  
								F999ActSal(oModelSOP, oModelFJR:GetValue("FJR_ORDPAG"), 1, oModelPAG:GetValue("EK_VALOR"))
							Else 
								F999ActSal(oModelSOP, oModelFJR:GetValue("FJR_ORDPAG"), Val(oModelPAG:GetValue("EK_MOEDA")), oModelPAG:GetValue("EK_VALOR"))
							EndIf	
						EndIf
					EndIf

				Else	
					//En caso de pa�ses dIferentes de Argentina no se toma la tabla FJS para identIficar si es D�bito Mediato o Inmediato, solo lo que se manda en la pantalla (nPagar o la Grid de Pago Especial EK_TIPODOC)
					cDebitoM := ""
					If Alltrim(oModelPAG:GetValue("EK_TIPO")) $ self:cDebMed
						cDebitoM := oModelPAG:GetValue("EK_TIPO")
					EndIf

					cDebitoI := ""
					If Alltrim(oModelPAG:GetValue("EK_TIPO")) $ self:cDebInm
						cDebitoI := oModelPAG:GetValue("EK_TIPO")
					EndIf

					If oModelPAG:GetValue("PGESP")
						nPag := VAL(oModelPAG:GetValue("EK_TIPODOC")) + 1
					Else
						nPag := VAL(oModelPAG:GetValue("EK_TIPODOC"))
						If oModelPAG:GetValue("SINCHS")
							nPag++
						EndIf
					EndIf
					
					lRet := self:F999GRVPGO(nPag, oModelPAG:GetValue("EK_TIPO"), cDebitoM, cDebitoI, oModel)

					F999ActSal(oModelSOP, oModelFJR:GetValue("FJR_ORDPAG"), Val(oModelPAG:GetValue("EK_MOEDA")), oModelPAG:GetValue("EK_VALOR"))

				EndIf

				nLine++
				If nLine <= oModelPAG:Length()
					oModelPAG:GoLine(nLine)
				EndIf
			EndDo
		EndIf

		//Grabado de Documentos de terceros
		If !Empty(oModelFJR:GetValue("FJR_ORDPAG")) .And. oModel3RO:SeekLine({{"E1_ORDPAGO", oModelFJR:GetValue("FJR_ORDPAG")}}, .F., .T.) 
			nLine := oModel3RO:GetLine()
			While nLine <= oModel3RO:Length() .And. oModelFJR:GetValue("FJR_ORDPAG") == oModel3RO:GetValue("E1_ORDPAGO")

				lRet := self:F999GRVPGO(4,,,, oModel)

				F999ActSal(oModelSOP, oModelFJR:GetValue("FJR_ORDPAG"), oModel3RO:GetValue("E1_MOEDA"), oModel3RO:GetValue("E1_SALDO"))

				// Punto de Entrada para actualizar campos del cheque (SEF)
				If self:lF999DOC3 
					aAreaSA2 := SA2->(GetArea())
					aAreaSE1 := SE1->(GetArea())
					aAreaSEF := SEF->(GetArea())

					SEF->(DbGoTo(oModel3RO:GetValue('RECSEF')))
					cPrefix  := SEF->EF_PREFIXO
					cNum     := SEF->EF_NUM
					cParcela := SEF->EF_PARCELA
					cTipoDoc := SEF->EF_TIPO
					SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
					SA2->(MsSeek(cFilSA2+oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")))
					SE1->(DbSetOrder(1)) //E1_FILIAL+E1_PREFIXO+E1_NUM+E1_PARCELA+E1_TIPO
					SE1->(MsSeek(cFilSE1+cPrefix+cNum+cParcela+cTipoDoc))
					cNum := SE1->E1_RECIBO
					SEF->(DbSetOrder(3)) //EF_FILIAL+EF_PREFIXO+EF_TITULO+EF_PARCELA+EF_TIPO+EF_NUM+EF_SEQUENC
					SEF->(MsSeek(cFilSEF+cPrefix+cNum+cParcela+cTipoDoc))
					// Actualiza los N registros del cheque
					Do while SEF->(!EOF()) .And. cFilSEF == SEF->EF_FILIAL .And. cPrefix == SEF->EF_PREFIXO .And. cNum == SEF->EF_TITULO .And.;
						cParcela == SEF->EF_PARCELA .And. cTipoDoc == SEF->EF_TIPO
						RecLock("SEF",.F.)
						ExecBlock("F850DOC3",.F.,.F.)
						SEF->(MsUnlock())
						SEF->(DbSkip())
					Enddo

					RestArea(aAreaSA2)
					RestArea(aAreaSE1)
					RestArea(aAreaSEF)
				EndIf

				nLine++
				If nLine <= oModel3RO:Length()
					oModel3RO:GoLine(nLine)
				EndIf
			EndDo
		EndIf
	Next

	FWFreeObj(jHdlPrv)

Return lRet

/*/{Protheus.doc} F999GRVPGO
	Funci�n encargada de grabar las formas de pago y los documentos de terceros de la orden de pago
	@type Method
	@author  Jos� Gonz�lez
	@since   20/04/2026
	@version 12.1.2310 / Superior
	@param	nPagar, Numeric, Tipo de Pago
	@param	cModPago, Character, Modo de Pago
	@param	cDebMed, Character, Debito mediato
	@param	cDebInm, Character, Debito inmediato
	@param	oModel, Object, Modelo FINA999
/*/
Method F999GRVPGO(nPagar, cModPago, cDebMed, cDebInm, oModel) Class F999PGO
Local cSeqFRF	:= ""
Local nMoedaBco	:= 1
Local nSize		:= 0
Local nValorTit	:= 0
Local lChMed	:= .F.
Local lChInMed	:= .F.
Local lRet		:= .T.
Local cFiltroSe2:= ""
Local nSeqSXE	:= 0
Local cCposSE5	:= ""
Local cIDDoc	:= ""
Local cChaveTit	:= ""
Local cIDSEF	:= ""
Local cRedNome  := ""
Local oModelEOP := oModel:GetModel('EOP_MASTER')
Local oModelFJR := oModel:GetModel('FJR_MASTER')
Local oModelMOE := oModel:GetModel('MOE_DETAIL')
Local oModelTTB := oModel:GetModel('TTB_DETAIL')
Local oModelPAG := oModel:GetModel('PAG_DETAIL') 
Local oModel3RO := oModel:GetModel('3RO_DETAIL') 
Local cBanco	:= oModelPAG:GetValue("EK_BANCO")
Local cAgencia	:= oModelPAG:GetValue("EK_AGENCIA")
Local cConta	:= oModelPAG:GetValue("EK_CONTA")
Local cNumChq  	:= oModelPAG:GetValue("EK_NUM")
Local cParcela 	:= oModelPAG:GetValue("EK_PARCELA")
Local dDtVcto	:= oModelPAG:GetValue("EK_VENCTO")
Local nTotal 	:= oModelPAG:GetValue("EK_VALOR")
Local dDtEmis 	:= oModelPAG:GetValue("EK_EMISSAO")
Local cTalao 	:= oModelPAG:GetValue("EK_TALAO")
Local cPrefixo 	:= oModelPAG:GetValue("EK_PREFIXO")
Local lBajaCh   := oModelPAG:GetValue("BAJACH")
Local nMoeda 	:= Val(oModelPAG:GetValue("EK_MOEDA"))
Local cFornece 	:= oModelFJR:GetValue("FJR_FORNEC")
Local cLoja 	:= oModelFJR:GetValue("FJR_LOJA")
Local cNome		:= oModelFJR:GetValue("NOMBRE")
Local cIDProc 	:= oModelFJR:GetValue("CIDPROC")
Local cLiquid	:= oModelFJR:GetValue("CLIQUID")
Local cOrdPago 	:= oModelFJR:GetValue("FJR_ORDPAG")
Local cNatureza	:= oModelFJR:GetValue("FJR_NATURE")
Local lCBU 		:= .F.
Local nValMOrig := oModelFJR:GetValue("VALORIG")
local nTxPromed := 0 	
local aTxProm   := {}
Local cOpcElt 	:= oModelEOP:GetValue("CPGTOELT") 
Local lPa		:= oModelEOP:GetValue("PA")
Local cJCotiz	:= ""
Local oJTxProm	:= JsonObject():New()
Local oJCotiz 	:= JsonObject():New()
Local nRecEQU	:= 0
Local nRegSE1	:= oModel3RO:GetValue('RECSE1')
Local aAreaSE2  := {}
Local aAreaSA6	:= {}
Local aAreaSEF	:= {}
Local cCampo	:= ""
Local aError	:= {}
Local cFunNm    := "FINA085A"
Local nTamEFNum := GetSx3Cache("EF_NUM", "X3_TAMANHO")
Local nTamE2Num := GetSx3Cache("E2_NUM", "X3_TAMANHO")
Local cFilSEF	:= xFilial("SEF")
Local cNum      := ""
Local nRecSE5   := 0
Local lProcITF  := .F.
Local lExist    := .T.

Default nPagar   := 0
Default cModPago := ""
Default cDebMed  := ""
Default cDebInm	 := ""
Default oModel   := Nil

self:oModBxE2 := FWLoadModel("FINM020")
self:oFKABxE2 := self:oModBxE2:GetModel("FKADETAIL")
self:oFK2BxE2 := self:oModBxE2:GetModel("FK2DETAIL")

self:oModBxE1 := FWLoadModel("FINM010")
self:oFKABxE1 := self:oModBxE1:GetModel("FKADETAIL")
self:oFK1BxE1 := self:oModBxE1:GetModel("FK1DETAIL")

self:oModMovBco := FWLoadModel("FINM030")
self:oFKAMovBco := self:oModMovBco:GetModel("FKADETAIL")
self:oFK5MovBco := self:oModMovBco:GetModel("FK5DETAIL")

If oModelEOP:GetValue("MODII")
	lCBU 		:= oModelFJR:GetValue("CBU")
	nTxPromed 	:= oModelFJR:GetValue("NTXPROM")  	
	cJCotiz		:= oModelEOP:GetValue("COTIZ")
	oJCotiz:FromJson(cJCotiz)
	oJTxProm:FromJson(oModelFJR:GetValue("ATXPROM"))
	aTxProm 	:= oJTxProm['txprom']
	cFunNm		:= "FINA850"
EndIf

If nPagar == 4
	nRecEQU := oModel3RO:GetValue('RECSEF')
Else
	nRecEQU := oModelPAG:GetValue('RECSEF')
EndIf

If !Empty(cBanco)
	SA6->(DbSetOrder(1)) //A6_FILIAL+A6_COD+A6_AGENCIA+A6_NUMCON
	SA6->(MsSeek(xFilial("SA6")+cBanco+cAgencia+cConta))
	If SA6->A6_MOEDAP > 0
		nMoedaBco := SA6->A6_MOEDAP
	Else
		nMoedaBco := SA6->A6_MOEDA
	EndIf
	nMoedaBco := Max(nMoedaBco, 1)
EndIf

SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
If  SA2->(MsSeek(xFilial("SA2")+cFornece+cLoja))
	cRedNome := SA2->A2_NREDUZ
EndIf

aAreaSE2  := SE2->(GetArea())

/*Pegar a numero que vou usar para numerar os documentos gerados.*/
If (nPagar == 2 .Or. nPagar == 3) .And. (Empty(cNumChq) .Or. Substr(cNumChq,1,1) == '*')
	If self:lF999NUM
		cNumChq	:= ExecBlock(self:cF999NUM,.F.,.F.,{nPagar,cFornece,cLoja,dDtVcto})
		If self:lF999PRECH
			cFiltroSE2 := SE2->(DbFilter())  //Guarda el filtro para que pueda ser consultado todo el SE2 no RDMAKE
	 		SE2->(DbClearFilter())
			cPrefixo := ExecBlock(self:cF999PRECH, .F., .F., {cNumChq, cFornece, cLoja, cBanco, cAgencia, cConta})
			DbSelectArea("SE2")
			SET FILTER TO &cFiltroSE2  // Restaura o filtro original
		EndIf
	Else
		aAreaSA6  := SA6->(GetArea())
		DbSelectArea("SA6")
		If nPagar == 2
			cCampo := "A6_NUM" + cDebMed
		Else
			cCampo := "A6_NUM" + cDebInm
		EndIf
		If SA6->(ColumnPos(cCampo)) > 0
			nSize	:=	Len(Alltrim(&cCampo.))
			If nSize == 0
				nSize := nTamE2Num
			EndIf
			cNumChq	:=	&cCampo
			If self:lVldCh
				aAreaSEF  := SEF->(GetArea())
				DbSelectArea("SEF")
				SEF->(DbSetOrder(1)) //EF_FILIAL+EF_BANCO+EF_AGENCIA+EF_CONTA+EF_NUM
				While lExist
					If !(SEF->(MsSeek(cFilSEF+cBanco+cAgencia+cConta+Substr(cNumChq,1,nTamEFNum))))
						lExist := .F.
					Else
						cNumChq := StrZero(Val(cNumChq)+1,nSize)
					EndIf
				Enddo
				RestArea(aAreaSEF)
			EndIf
			Reclock("SA6",.F.)
			&cCampo	:= StrZero(Val(&cCampo.)+1, nSize)
			SA6->(MsUnLock())
		Else
			cNumChq	:= cOrdPago
		EndIf
		RestArea(aAreaSA6)
	EndIf

	// VALIDACAO PARA VERIfICAR SE ESTE NUMERO DE CHEQUE JA ESTA CADASTRADO NO SE2, E CASO ESTEJA
	// AUMENTAR O NUMERO DA PARCELA PARA NAO GERAR DUPLICIDADE
	If self:lVldCh
	    cNum := Padr(cNumChq, nTamE2Num)
		cFiltroSE2 := SE2->(DbFilter())  // Salva o filtro para que possa ser consultado todo o SE2 no RDMAKE
		SE2->(DbClearFilter())
		DbSelectArea("SE2")
		SE2->(DbSetOrder(1)) //E2_FILIAL+E2_PREFIXO+E2_NUM+E2_PARCELA+E2_TIPO+E2_FORNECE+E2_LOJA
		If SE2->(MsSeek(xFilial("SE2")+Space(GetSx3Cache("E2_PREFIXO","X3_TAMANHO")) + cNum + cParcela + cDebMed + cFornece + cLoja)) .And. SE2->E2_PORTADO <> cBanco
			If Empty(cParcela)
				cParcela := self:c1Dup
			Else
				Soma1(cParcela,, .T.)
			EndIf
		EndIf
		DbSelectArea("SE2")
		SET FILTER TO &cFiltroSE2  // Restaura o filtro original
	EndIf
EndIf

//Gravar os debitos inmediatos (Transferencias, Cash, Cartao de debito, etc)
If 	nPagar == 3 .And. nTotal > 0 .And. !(AllTrim(cDebInm) $ MVCHEQUE) .And. cOpcElt <> "1"
	self:oModMovBco:SetOperation(MODEL_OPERATION_INSERT)
	self:oModMovBco:Activate()
	self:oModMovBco:SetValue("MASTER","E5_GRV",.T.)
	self:oModMovBco:SetValue("MASTER","IDPROC",cIDProc)

	cCposSE5 := "{"
	cCposSE5 += "{'E5_DTDIGIT',dDataBase},"
	cCposSE5 += "{'E5_VENCTO',dDataBase},"
	cCposSE5 += "{'E5_TIPO','" + cDebInm + "'},"
	cCposSE5 += "{'E5_NUMLIQ','" + cLiquid + "'},"
	cCposSE5 += "{'E5_PREFIXO',''},"
	cCposSE5 += "{'E5_NUMERO','" + cNumChq + "'},"
	cCposSE5 += "{'E5_PARCELA','" + cParcela + "'},"
	cCposSE5 += "{'E5_CLIfOR','" + cFornece + "'},"
	cCposSE5 += "{'E5_LOJA','"  + cLoja + "'},"
	If !Empty(cNome)
		cCposSE5 += "{'E5_BENEF','" + cNome + "'},"
	Else
		cCposSE5 += "{'E5_BENEF','" + cRedNome + "'},"
	EndIf
	cCposSE5 += "{'E5_MOTBX','NOR'}"
	cCposSE5 += "}"

	self:oModMovBco:SetValue("MASTER","E5_CAMPOS",cCposSE5)
	self:oFKAMovBco:SetValue("FKA_IDORIG"	,FWUUIDV4())
	self:oFKAMovBco:SetValue("FKA_TABORI"	,"FK5")

	self:oFK5MovBco:SetValue("FK5_VALOR"	,Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco)))
	self:oFK5MovBco:SetValue("FK5_RECPAG"	,"P")
	self:oFK5MovBco:SetValue("FK5_HISTOR"	,STR0066+ ' ' + cOrdPago) //"Ord. pago "
	self:oFK5MovBco:SetValue("FK5_DATA"		,dDataBase)
	self:oFK5MovBco:SetValue("FK5_NATURE"	,cNatureza)
	self:oFK5MovBco:SetValue("FK5_TPDOC"	,"VL")
	//Gravar a moeda2 em moeda 1 para facilitar a contabilizacao
	self:oFK5MovBco:SetValue("FK5_VLMOE2"	,Round(xMoeda(nTotal,nMoeda,1,,5,oModelMOE:GetValue('TASA',nMoeda),),MsDecimais(1)))
	self:oFK5MovBco:SetValue("FK5_ORDREC"	,cOrdPago)
	self:oFK5MovBco:SetValue("FK5_BANCO"	,cBanco)
	self:oFK5MovBco:SetValue("FK5_AGENCI"	,cAgencia)
	self:oFK5MovBco:SetValue("FK5_CONTA"	,cConta)
	self:oFK5MovBco:SetValue("FK5_NUMCH"	,cNumChq)
	self:oFK5MovBco:SetValue("FK5_MOEDA"	,StrZero(nMoedaBco,2))
	self:oFK5MovBco:SetValue("FK5_DTDISP"	,dDtVcto)
	self:oFK5MovBco:SetValue("FK5_FILORI"	,SubString(cFilAnt,1,len(FK5->FK5_FILIAL)))
	self:oFK5MovBco:SetValue("FK5_ORIGEM"	,cFunNm)
	self:oFK5MovBco:SetValue("FK5_TXMOED"	,oModelMOE:GetValue('TASA',nMoedaBco))

	If self:lMarkLa
		self:oFK5MovBco:SetValue("FK5_LA"	,"S")
	EndIf

	If self:oModMovBco:VldData()
		self:oModMovBco:CommitData()
		AtuSalBco(FK5->FK5_BANCO,FK5->FK5_AGENCIA,FK5->FK5_CONTA,dDtVcto,FK5->FK5_VALOR,"-")
		If self:lCalcITF
			nRecSE5  := self:oModMovBco:GetValue("MASTER", "E5_RECNO")
			lProcITF := self:lFindITF .And. FinProcITF(nRecSE5, 1) .And. F999CkPG(FK5->FK5_BANCO,,,.T.)
			If lPa
				If lProcITF
					If oModelFJR:GetValue("BASEITF") == 0
						oModelFJR:LoadValue("BASEITF", FK5->FK5_VALOR)
					EndIf
				Else
					oModelFJR:LoadValue("BASEITF", 0)
				EndIf
			Else
				If lProcITF
					oModelFJR:LoadValue("BASEITF", FK5->FK5_VALOR)
				EndIf
			EndIf
			//verifico se o sistema esta parametrizado corretamente para efetuar lancamento do imposto ITF
			If lProcITF .And. oModelFJR:GetValue("BASEITF") > 0
				//faco o lancamento do imposto ITF na movimentacao bancaria e retorno os dados para contabilizacao
				FinProcITF(nRecSE5, 3, oModelFJR:GetValue("BASEITF"), .F., self:aHdlPrv)
			EndIf
		EndIf
	Else
		aError := self:oModMovBco:GetErrorMessage()
		If Len(aError) >= 6
			self:cLog := cValToChar(aError[4]) + ' - '
			self:cLog += cValToChar(aError[5]) + ' - '
			self:cLog += cValToChar(aError[6])
			self:cMsj := "ORDPAG_DBIM"
		EndIf
		lRet := .F.
	EndIf
	self:oModMovBco:DeActivate()

//Gravar os debitos mediatos (Cheques, Letras, Etc), e os cheques de deb. inmediato.
ElseIf nPagar <> 4
	If (nPagar == 2 .Or. nPagar == 1) .And. Trim(cDebMed) == Trim(MVCHEQUE)
		lChMed := .T.
	EndIf
	If nPagar == 3 .And. Trim(cDebInm) == Trim(MVCHEQUE)
		lChInMed := .T.
	EndIf
	If (lChMed .Or. lChInMed) .And. nTotal > 0
		If nRecEQU > 0
			SEF->(DbGoTo(nRecEQU))
			If SEF->(Recno()) == nRecEQU
				cPrefixo := SEF->EF_PREFIXO
				RecLock("SEF",.F.)
				SEF->EF_VALOR   := Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco))
				//Grava o numero do cheque somente se for pagamento dIferenciado
				SEF->EF_BENEF	:= cNome
				SEF->EF_VENCTO	:= dDtVcto 	
				SEF->EF_DATA	:= dDtEmis
				SEF->EF_HIST 	:= STR0066 + cOrdPago //"Ord. pago "
				If nPagar == 1
					SEF->EF_LIBER 	:= self:cLibCheq
				Else
					SEF->EF_LIBER 	:= "S"
				EndIf
				SEF->EF_FORNECE	:= cFornece
				SEF->EF_LOJA	:= cLoja
				SEF->EF_LA     	:= "S"
				SEF->EF_SEQUENC	:= PadL("1",GetSx3Cache("EF_SEQUENC","X3_TAMANHO"),"0") 
				SEF->EF_PARCELA	:= cParcela

				If lChInMed 
					SEF->EF_STATUS	:= "04"
					SEF->EF_REFTIP	:= "LP"
				Else
					SEF->EF_STATUS	:= "02"
				EndIf

				SEF->EF_ORDPAGO	:= cOrdPago
				SEF->EF_IDSEF	:= FWUUIDV4()
				SEF->EF_TITULO  := cOrdPago
				SEF->EF_TIPO    := Trim(MVCHEQUE)
				SEF->EF_ORIGEM 	:= cFunNm
				SEF->EF_FILCHQ	:= cFilAnt

				SEF->(MsUnlock())

				cSeqFRF := GetSx8Num("FRF","FRF_SEQ")

				RecLock("FRF",.T.)
				FRF->FRF_FILIAL		:= xFilial("FRF")
				FRF->FRF_BANCO		:= SEF->EF_BANCO
				FRF->FRF_AGENCIA	:= SEF->EF_AGENCIA
				FRF->FRF_CONTA		:= SEF->EF_CONTA
				FRF->FRF_NUM		:= SEF->EF_NUM
				FRF->FRF_PREFIX		:= SEF->EF_PREFIXO
				FRF->FRF_CART		:= "P"
				FRF->FRF_DATPAG		:= dDataBase
				FRF->FRF_MOTIVO		:= "99"
				FRF->FRF_DESCRI		:= STR0067 //"CHEQUE VINCULADO A PAGO"
				FRF->FRF_SEQ		:= cSeqFRF
				FRF->FRF_FORNEC		:= cFornece
				FRF->FRF_LOJA		:= cLoja
				FRF->FRF_NUMDOC		:= cOrdPago
				FRF->(MsUnLock())

				//Confirma a numera��o do historico
				ConfirmSX8()

				//Se for cheque que gera movimento banc�rio, gera o hist�rico de liquida��o
				If lChInMed .And. cOpcElt <> "1"
					cSeqFRF := GetSx8Num("FRF","FRF_SEQ")
					RecLock("FRF",.T.)
					FRF->FRF_FILIAL		:= xFilial("FRF")
					FRF->FRF_BANCO		:= SEF->EF_BANCO
					FRF->FRF_AGENCIA	:= SEF->EF_AGENCIA
					FRF->FRF_CONTA		:= SEF->EF_CONTA
					FRF->FRF_NUM		:= SEF->EF_NUM
					FRF->FRF_PREFIX		:= SEF->EF_PREFIXO
					FRF->FRF_CART		:= "P"
					FRF->FRF_DATPAG		:= dDataBase
					FRF->FRF_MOTIVO		:= "10"
					FRF->FRF_DESCRI		:= STR0068 //"CHEQUE COMPENSADO"
					FRF->FRF_SEQ		:= cSeqFRF
					FRF->FRF_FORNEC		:= cFornece
					FRF->FRF_LOJA		:= cLoja
					FRF->FRF_NUMDOC		:= cOrdPago
					FRF->(MsUnLock())

					ConfirmSX8()
				EndIf
			EndIf
		Else
			RecLock("SEF",.T.)
			SEF->EF_FILIAL 	:= cFilSEF
			SEF->EF_VALOR   := Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco))
			If nPagar == 2 .And. Trim(cDebMed) == Trim(MVCHEQUE)
				SEF->EF_NUM	:= cNumChq
			EndIf
			SEF->EF_BANCO	:= cBanco
			SEF->EF_AGENCIA	:= cAgencia
			SEF->EF_CONTA	:= cConta
			SEF->EF_BENEF	:= cNome
			SEF->EF_VENCTO	:= dDtVcto
			SEF->EF_DATA	:= dDtEmis
			SEF->EF_HIST 	:= STR0066 + cOrdPago //"Ord. pago "
			SEF->EF_CART 	:= "P"
			If nPagar == 1
				SEF->EF_LIBER := self:cLibCheq
			Else
				SEF->EF_LIBER := "S"
			EndIf
			SEF->EF_ORIGEM 	:= cFunNm
			SEF->EF_FORNECE	:= cFornece
			SEF->EF_LOJA	:= cLoja
			SEF->EF_LA     	:= "S"
			SEF->EF_SEQUENC	:= "01"
			If lBajaCh
				SEF->EF_STATUS	:=	"02"
			EndIf
			SEF->EF_PARCELA	:= cParcela
			If nPagar == 1
				SEF->EF_TITULO  := cOrdPago
				SEF->EF_TIPO    := "ORP"
			Else
				SEF->EF_TITULO  := cOrdPago
				SEF->EF_TIPO    := Trim(MVCHEQUE)
			EndIf
			SEF->(MsUnlock())
		EndIf
	EndIf

	If (nPagar == 2 .Or. lChInMed) .And. nTotal > 0 .And. cOpcElt <> "1"  // debito mediato (CH)
		DbSelectArea("SE2")
		// GERAR SE2
		RecLock("SE2",.T.)
		SE2->E2_FILIAL		:= xFilial("SE2")
		SE2->E2_FILORIG  	:= cFilAnt
		SE2->E2_NUMLIQ		:= cLiquid
		If SEF->(Recno()) == nRecEQU
			SE2->E2_NUMBCO	:= cNumChq
			cPrefixo 		:= SEF->EF_PREFIXO
		EndIf
		SE2->E2_NUM   		:= cNumChq
		SE2->E2_PREFIXO 	:= cPrefixo
		If lChInMed
			SE2->E2_TIPO := cDebInm
		Else
			SE2->E2_TIPO := cDebMed
		EndIf
		SE2->E2_NATUREZ 	:= cNatureza
		SE2->E2_FORNECE		:= cFornece
		SE2->E2_LOJA  		:= cLoja
		If !Empty(cNome)
			SE2->E2_NOMFOR := cNome
		Else
			SE2->E2_NOMFOR := cRedNome
		EndIf
		SE2->E2_EMISSAO		:= dDtEmis
		SE2->E2_EMIS1 		:= dDtEmis
		SE2->E2_VENCTO		:= dDtVcto
		SE2->E2_VENCREA		:= DataValida(dDtVcto,.T.)
		nValorTit			:= Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco))
		SE2->E2_VALOR   	:= nValorTit
		SE2->E2_VENCORI		:= DataValida(dDtVcto,.T.)
		SE2->E2_PARCELA 	:= cParcela
		If lBajaCh .Or. lChInMed
			SE2->E2_VALLIQ  := nValorTit
			SE2->E2_SALDO   := 0
			SE2->E2_BAIXA   := dDataBase
			SE2->E2_MOVIMEN := dDataBase
			SE2->E2_BCOPAG  := cBanco
		Else
			SE2->E2_SALDO   := nValorTit
		EndIf
		SE2->E2_VLCRUZ 		:= Round(xMoeda(nTotal,nMoedaBco,1,,5,oModelMOE:GetValue('TASA',nMoeda)),MsDecimais(1))
		SE2->E2_MOEDA   	:= nMoedaBco
		SE2->E2_SITUACA  	:= "0"
		SE2->E2_PORTADO  	:= cBanco
		SE2->E2_BCOCHQ   	:= cBanco
		SE2->E2_AGECHQ   	:= cAgencia
		SE2->E2_CTACHQ   	:= cConta
		SE2->E2_ORDPAGO  	:= cOrdPago
		SE2->E2_ORIGEM 		:= cFunNm
		SE2->E2_LA       	:= "S"
		SE2->E2_TXMOEDA 	:= oModelMOE:GetValue('TASA',Max(nMoedaBco,1))//GRAVA A TAXA DA MOEDA DO PA
		SE2->E2_DATALIB		:= dDtEmis

		If self:lCgc
			SE2->E2_CGC	    := SA2->A2_CGC
		EndIf

		If self:lDtLib
			SE2->E2_DATALIB := dDtEmis
		EndIf

		SE2->(MsUnlock())
		FKCommit()

		If (lBajaCh .And. !self:lBxE2) .Or. lChInMed
			self:oModBxE2:SetOperation(MODEL_OPERATION_INSERT)
			self:oModBxE2:Activate()
			self:oModBxE2:SetValue("MASTER","E5_GRV",.T.)
			self:oModBxE2:SetValue("MASTER","IDPROC",cIDProc)

			cCposSE5 := "{"
			cCposSE5 += "{'E5_DTDIGIT',dDataBase},"
			If lChInMed
				cCposSE5 += "{'E5_TIPO','" +cDebInm + "'},"
			Else
				cCposSE5 += "{'E5_TIPO','" +cDebMed + "'},"
			EndIf
			cCposSE5 += "{'E5_NUMLIQ','" + cLiquid + "'},"
			cCposSE5 += "{'E5_PREFIXO','" + cPrefixo + "'},"
			cCposSE5 += "{'E5_NUMERO','" + cNumChq + "'},"
			cCposSE5 += "{'E5_PARCELA','" + cParcela + "'},"
			cCposSE5 += "{'E5_CLIfOR','" + cFornece + "'},"
			cCposSE5 += "{'E5_LOJA','"  + cLoja + "'},"
			If !Empty(cNome)
				cCposSE5 += "{'E5_BENEF','" + cNome + "'},"
			Else
				cCposSE5 += "{'E5_BENEF','" + cRedNome + "'},"
			EndIf
			cCposSE5 += "{'E5_BANCO','" + cBanco + "'},"
			cCposSE5 += "{'E5_AGENCIA','" + cAgencia + "'},"
			cCposSE5 += "{'E5_CONTA','" + cConta + "'},"
			cCposSE5 += "{'E5_DTDISPO',Ctod('" + Dtoc(dDtVcto) + "')}"
			cCposSE5 += "}"

			cChaveTit := xFilial("SE2") + "|"
			cChaveTit += cPrefixo + "|"
			cChaveTit += cNumChq + "|"
			cChaveTit += cParcela + "|"
			If lChInMed
				cChaveTit += cDebInm + "|"
			Else
				cChaveTit += cDebMed + "|"
			EndIf
			cChaveTit += cFornece + "|"
			cChaveTit += cLoja
			cIdDoc := FINGRVFK7("SE2", cChaveTit)

			self:oModBxE2:SetValue("MASTER","E5_CAMPOS",cCposSE5)
			self:oFKABxE2:SetValue("FKA_IDORIG"	,FWUUIDV4())
			self:oFKABxE2:SetValue("FKA_TABORI"	,"FK2")

			self:oFK2BxE2:SetValue("FK2_VALOR"	,Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco)))
			self:oFK2BxE2:SetValue("FK2_RECPAG"	,"P")
			self:oFK2BxE2:SetValue("FK2_HISTOR"	,STR0069)		// "DEBITO CC"
			self:oFK2BxE2:SetValue("FK2_DATA"	,dDataBase)
			self:oFK2BxE2:SetValue("FK2_TPDOC"	,"VL")
			//Gravar a moeda2 em moeda 1 para facilitar a contabilizacao
			If lPa
				self:oFK2BxE2:SetValue("FK2_VLMOE2",Round(xMoeda(nTotal,nMoeda,1,,5,oModelMOE:GetValue('TASA',nMoeda)),5))
			Else
				self:oFK2BxE2:SetValue("FK2_VLMOE2",nValMOrig)
		  	EndIf
			self:oFK2BxE2:SetValue("FK2_SEQ"	,PadL("1",GetSx3Cache("E5_SEQ","X3_TAMANHO"),"0")) 
			self:oFK2BxE2:SetValue("FK2_MOEDA"	,StrZero(nMoedaBco,2))
			self:oFK2BxE2:SetValue("FK2_NATURE"	,cNatureza)
			self:oFK2BxE2:SetValue("FK2_TXMOED"	,oModelMOE:GetValue('TASA',nMoedaBco))
			If lChInMed
				self:oFK2BxE2:SetValue("FK2_MOTBX"	,"NOR")
			Else
				self:oFK2BxE2:SetValue("FK2_MOTBX"	,"DEB")
			EndIf
			self:oFK2BxE2:SetValue("FK2_FILORI"	,cFilAnt)
			self:oFK2BxE2:SetValue("FK2_IDDOC"	,cIdDoc)
			self:oFK2BxE2:SetValue("FK2_ORIGEM"	,cFunNm)

			If self:oModBxE2:VldData()
				self:oModBxE2:CommitData()
				AtuSalBco(FK5->FK5_BANCO,FK5->FK5_AGENCIA,FK5->FK5_CONTA,dDtVcto,FK5->FK5_VALOR,"-")
				
				If self:lCalcITF
					nRecSE5  := self:oModBxE2:GetValue("MASTER", "E5_RECNO")
					lProcITF := self:lFindITF .And. FinProcITF(nRecSE5, 1)
					//verifico se o sistema esta parametrizado corretamente para efetuar lancamento do imposto ITF
					IF self:lAjusITF .And. lProcITF
						oModelFJR:LoadValue("BASEITF", FK5->FK5_VALOR)
					EndIf
					If lProcITF .And. oModelFJR:GetValue("BASEITF") > 0 .And. F999CkPG(FK5->FK5_BANCO,,,.T.)
						//faco o lancamento do imposto ITF na movimentacao bancaria e retorno os dados para contabilizacao
						FinProcITF(nRecSE5, 3, oModelFJR:GetValue("BASEITF"), .F., self:aHdlPrv)
					EndIf
				EndIf
			Else
				aError := self:oModBxE2:GetErrorMessage()
				If Len(aError) >= 6
					self:cLog := cValToChar(aError[4]) + ' - '
					self:cLog += cValToChar(aError[5]) + ' - '
					self:cLog += cValToChar(aError[6])
					self:cMsj := "ORDPAG_DBMEBXCH"
				EndIf
				lRet := .F.
			EndIf
			self:oModBxE2:DeActivate()
		Else
			Reclock("SA2",.F.)
			SA2->A2_SALDUP	:= SA2->A2_SALDUP  + Round(xMoeda(nValorTit,nMoedaBco,1,,5,oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(1))
			SA2->A2_SALDUPM	:= SA2->A2_SALDUPM + Round(xMoeda(nValorTit,nMoedaBco,self:nMVCusto,,5,oModelMOE:GetValue('TASA',nMoedaBco),oModelMOE:GetValue('TASA',self:nMVCusto)),MsDecimais(self:nMVCusto))
			SA2->(MsUnlock())
		EndIf
	EndIf
Else
	//Baixar cheques de terceiros aplicados no pagamento
	/*atualiza o controle de cheques recebidos*/
	If !Empty(nRecEQU)
		SEF->(DbGoTo(nRecEQU))
		If SEF->(Recno()) == nRecEQU
			RecLock("SEF",.F.)
			SEF->EF_ORDPAGO	:= cOrdPago
			SEF->EF_STATUS	:= "09"
			SEF->EF_FILCHQ	:= cFilAnt
			SEF->(MsUnLock())
			/*Registra el movimento en el archivo de historicos*/
			cSeqFRF := GetSx8Num("FRF","FRF_SEQ")
			RecLock("FRF",.T.)
			FRF->FRF_FILIAL	:= xFilial("FRF")
			FRF->FRF_BANCO	:= SEF->EF_BANCO
			FRF->FRF_AGENCI	:= SEF->EF_AGENCIA
			FRF->FRF_CONTA	:= SEF->EF_CONTA
			FRF->FRF_NUM	:= SEF->EF_NUM
			FRF->FRF_PREFIX	:= SEF->EF_PREFIXO
			FRF->FRF_CART	:= "P"
			FRF->FRF_DATPAG	:= dDataBase
			FRF->FRF_MOTIVO	:= "99"
			FRF->FRF_DESCRI	:= STR0067 //"CHEQUE VINCULADO A PAGO"
			FRF->FRF_SEQ	:= cSeqFRF
			FRF->FRF_FORNEC	:= cFornece
			FRF->FRF_LOJA	:= cLoja
			FRF->FRF_NUMDOC	:= cOrdPago
			FRF->(MsUnLock())
			ConfirmSX8()
		EndIf		
	EndIf

	If nRegSE1 # nil
		SE1->(MsGoto(nRegSE1))
		If !SE1->(Eof())
			self:oModBxE1:SetOperation(MODEL_OPERATION_INSERT)
			self:oModBxE1:Activate()
			self:oModBxE1:SetValue("MASTER","E5_GRV",.T.)
			self:oModBxE1:SetValue("MASTER","IDPROC",cIDProc)
			cCposSE5 := "{"
			cCposSE5 += "{'E5_DTDIGIT',dDataBase},"
			cCposSE5 += "{'E5_PREFIXO','" + SE1->E1_PREFIXO + "'},"
			cCposSE5 += "{'E5_NUMERO','" + SE1->E1_NUM + "'},"
			cCposSE5 += "{'E5_BCOCHQ','" + SE1->E1_BCOCHQ + "'},"
			cCposSE5 += "{'E5_AGECHQ','" + SE1->E1_AGECHQ + "'},"
			cCposSE5 += "{'E5_CTACHQ','" + SE1->E1_CTACHQ + "'},"
			cCposSE5 += "{'E5_PARCELA','" + SE1->E1_PARCELA + "'},"
			cCposSE5 += "{'E5_CLIfOR','" + SE1->E1_CLIENTE + "'},"
			cCposSE5 += "{'E5_LOJA','" + SE1->E1_LOJA + "'},"
			cCposSE5 += "{'E5_BENEF','" + cFornece+cLoja + "'},"
			cCposSE5 += "{'E5_TIPO','" + SE1->E1_TIPO + "'},"
			cCposSE5 += "{'E5_NUMLIQ','" + cLiquid + "'}"
			cCposSE5 += "}"

			cChaveTit := xFilial("SE1") + "|"
			cChaveTit += SE1->E1_PREFIXO + "|"
			cChaveTit += SE1->E1_NUM + "|"
			cChaveTit += SE1->E1_PARCELA + "|"
			cChaveTit += SE1->E1_TIPO + "|"
			cChaveTit += SE1->E1_CLIENTE + "|"
			cChaveTit += SE1->E1_LOJA
			cIdDoc := FINGRVFK7("SE1", cChaveTit)

			self:oModBxE1:SetValue("MASTER","E5_CAMPOS",cCposSE5)
			cIDSEF := FWUUIDV4()
			self:oFKABxE1:SetValue("FKA_IDORIG"	,cIDSEF)
			self:oFKABxE1:SetValue("FKA_TABORI"	,"FK1")

			self:oFK1BxE1:SetValue("FK1_RECPAG"	,"R")
			self:oFK1BxE1:SetValue("FK1_HISTOR"	,STR0078+cOrdPago) //"Entregado OP "
			self:oFK1BxE1:SetValue("FK1_DATA"	,SE1->E1_EMISSAO)
			self:oFK1BxE1:SetValue("FK1_NATURE"	,SE1->E1_NATUREZ)
			self:oFK1BxE1:SetValue("FK1_VENCTO"	,SE1->E1_VENCTO)
			self:oFK1BxE1:SetValue("FK1_TPDOC"	,"BA")
			self:oFK1BxE1:SetValue("FK1_MOTBX"	,"LIQ")
			self:oFK1BxE1:SetValue("FK1_VLMOE2"	,SE1->E1_VALOR)
			self:oFK1BxE1:SetValue("FK1_SEQ"	,PadL("1",GetSx3Cache("E5_SEQ","X3_TAMANHO"),"0")) 
			self:oFK1BxE1:SetValue("FK1_DOC"	,cOrdPago)
			self:oFK1BxE1:SetValue("FK1_ORDREC"	,cOrdPago)
			self:oFK1BxE1:SetValue("FK1_MOEDA"	,StrZero(SE1->E1_MOEDA,2))
			self:oFK1BxE1:SetValue("FK1_VALOR"	,SE1->E1_VLCRUZ)
			self:oFK1BxE1:SetValue("FK1_IDDOC"	,cIdDoc)
			self:oFK1BxE1:SetValue("FK1_FILORI"	,SE1->E1_FILORIG)
			self:oFK1BxE1:SetValue("FK1_ORIGEM"	,cFunNm)
			self:oFK1BxE1:SetValue("FK1_LA"		,"S")

			If self:oModBxE1:VldData()
				self:oModBxE1:CommitData()
				RecLock("SEK",.T.)
				SEK->EK_FILIAL   := xFilial("SEK")
				SEK->EK_TIPODOC  := "CT" //CHEQUE Tercero
				SEK->EK_PREFIXO  := SE1->E1_PREFIXO
				SEK->EK_NUM      := SE1->E1_NUM
				SEK->EK_PARCELA  := SE1->E1_PARCELA
				SEK->EK_TIPO     := SE1->E1_TIPO
				SEK->EK_VALOR    := SE1->E1_VALOR
				SEK->EK_SALDO    := SE1->E1_SALDO
				SEK->EK_MOEDA    := AllTrim(Str(SE1->E1_MOEDA))
				SEK->EK_BANCO    := SE1->E1_BCOCHQ
				SEK->EK_AGENCIA  := SE1->E1_AGECHQ
				SEK->EK_CONTA    := SE1->E1_CTACHQ
				SEK->EK_ENTRCLI  := SE1->E1_CLIENTE
				SEK->EK_LOJCLI   := SE1->E1_LOJA
				SEK->EK_EMISSAO  := SE1->E1_EMISSAO
				SEK->EK_VENCTO   := SE1->E1_VENCTO
				SEK->EK_VLMOED1  := Round(xMoeda(SE1->E1_VALOR,SE1->E1_MOEDA,1, dDataBase,5,oModelMOE:GetValue('TASA',SE1->E1_MOEDA)),MsDecimais(1))
				SEK->EK_ORDPAGO  := cOrdPago
				SEK->EK_DTDIGIT  := dDataBase
				SEK->EK_FORNECE  := cFornece
				SEK->EK_LOJA     := cLoja
				SEK->EK_FORNEPG  := cFornece
				SEK->EK_LOJAPG   := cLoja

				If self:lCBU
					SEK->EK_PGCBU := lCBU
				EndIf

				If self:lDesc .And. oModelFJR:HasField("DCONCEP")
				   SEK->EK_DCONCEP := Alltrim(oModelFJR:GetValue("DCONCEP"))
				EndIf

				If self:lNat
					SEK->EK_NATUREZ := cNatureza
				EndIf

				F999GrvTx(oJCotiz['MonedaCotiz'], nTxPromed, aTxProm, oJCotiz, oModelMOE,, .T.) 
				SEK->(MsUnlock())
			Else
				aError := self:oModBxE1:GetErrorMessage()
				If Len(aError) >= 6
					self:cLog := cValToChar(aError[4]) + ' - '
					self:cLog += cValToChar(aError[5]) + ' - '
					self:cLog += cValToChar(aError[6])
					self:cMsj := "ORDPAG_DBDT"
				EndIf
				lRet := .F.
			EndIf
			self:oModBxE1:DeActivate()
		EndIf
	EndIf
EndIf

If lRet .And. nPagar <> 4
	//No puede ser grabado un documento con valor de 0
	If nTotal > 0
		RecLock("SEK",.T.)
		SEK->EK_FILIAL		:= xFilial("SEK")
		SEK->EK_TIPODOC		:= "CP"     //CHEQUE PROPIO
		SEK->EK_NUM			:= cNumChq
		If nPagar == 3
			SEK->EK_TIPO 	:= cDebInm
		ElseIf nPagar == 2
			SEK->EK_TIPO 	:= cDebMed
		Else
			SEK->EK_TIPO 	:= "CA"
		EndIf
		SEK->EK_FORNECE		:= cFornece
		SEK->EK_LOJA   		:= cLoja
		SEK->EK_EMISSAO		:= dDtEmis
		SEK->EK_VENCTO 		:= dDtVcto
		SEK->EK_VALOR  		:= Round(xMoeda(nTotal,nMoeda,nMoedaBco,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(nMoedaBco))
		SEK->EK_VLMOED1		:= Round(xMoeda(nTotal,nMoeda,1,,5,oModelMOE:GetValue('TASA',nMoeda),oModelMOE:GetValue('TASA',nMoedaBco)),MsDecimais(1))
		SEK->EK_MOEDA 		:= AllTrim(Str(nMoedaBco))
		SEK->EK_BANCO 		:= cBanco
		SEK->EK_AGENCIA		:= cAgencia
		SEK->EK_CONTA 		:= cConta
		SEK->EK_ORDPAGO		:= cOrdPago
		SEK->EK_DTDIGIT		:= dDataBase
		SEK->EK_FORNEPG 	:= cFornece
		SEK->EK_LOJAPG  	:= cLoja
		SEK->EK_PARCELA 	:= cParcela
		SEK->EK_PREFIXO 	:= cPrefixo

		If self:lTalao
			SEK->EK_TALAO	:= cTalao
		EndIf

		If self:lCBU
			SEK->EK_PGCBU 	:= lCBU
		EndIf

		If self:lNat
			SEK->EK_NATUREZ := cNatureza
		EndIf

		If self:lElt		
			SEK->EK_PGTOELT := cOpcElt
			SEK->EK_MODPAGO := cModPago
		EndIf

		If self:lF999PRECH
			SEK->EK_PREFIXO := cPrefixo
		EndIf
		
		F999GrvTx(oJCotiz['MonedaCotiz'], nTxPromed, aTxProm, oJCotiz, oModelMOE,, .T.) 
		SEK->(MsUnlock())

		If self:lF999GRA
			ExecBlock(self:cF999GRA,.f.,.f.)
		EndIf

		If self:lElt		
			//Actualiza el encabezado de la orden de pago
			DbSelectArea("FJR")
			DbSetOrder(1) //FJR_FILIAL+FJR_ORDPAG
			If MsSeek(XFilial("FJR")+SEK->EK_ORDPAGO)
				RecLock("FJR",.F.)
				FJR->FJR_PGTELT := cOpcElt
				FJR->(MsUnlock())
			EndIf
		EndIf
	EndIf
EndIf

If self:lF999PAG
	ExecBlock(self:cF999PAG,.F.,.F.)
EndIf

RestArea(aAreaSE2)

Return(lRet)
