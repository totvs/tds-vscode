#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'fina999.ch'

#DEFINE SOURCEFATHER "FINA999"

/*/{Protheus.doc} FINA999PAR
	Fuente de Modelo de Datos de Orden de Pago Localizado para Paraguay
	@type 		Function
	@author 	carlos.espinoza
	@since 		15/10/2025
	@version	12.1.2310 / Superior
/*/
Function FINA999PAR()
Local oBrowse := Nil
	
	oBrowse := BrowseDef()
	oBrowse:Activate()
	
Return Nil

/*/{Protheus.doc} BrowseDef
	Definici�n de Browse
	@type 		Function
	@author	 	carlos.espinoza
	@since 		15/10/2025
	@version	12.1.2310 / Superior
/*/
Static Function BrowseDef()
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
	Define las operaciones que ser�n realizadas por la aplicaci�n
	@type 		Function
	@author 	carlos.espinoza
	@since 		15/10/2025
	@version	12.1.2310 / Superior
/*/
Static Function MenuDef()
Local aRotina := {}
	
aRotina := FWLoadMenuDef(SOURCEFATHER)

Return aRotina

/*/{Protheus.doc} ModelDef
	Defini��o do modelo de Dados
	@type 		Function
	@author 	carlos.espinoza
	@since 		15/10/2025
	@version	12.1.2310 / Superior
	@return		Object, Modelo de dados
/*/
Static Function ModelDef()
Local oModel		:= FwLoadModel(SOURCEFATHER)
Local oStruFJR		:= oModel:GetModel('FJR_MASTER'):GetStruct()
Local oStruSFE		:= FWFormStruct(1, 'SFE', , .F.)
Local oMdlEvent		:= FINV999PAR():New()
Local oRetEvent		:= F999RETPAR():New()

	oStruFJR:AddField(STR0027	, STR0027	, 'IVA'			, 'N' , 16, 2)		// "Ret. IVA"
	oStruFJR:AddField(STR0065	, STR0065	, 'IR'			, 'N' , 16, 2)		// "Ret. IR"

	oModel:addGrid('SFE_DETAIL','EOP_MASTER',oStruSFE,,)	// Retenciones

	oModel:GetModel('SFE_DETAIL'):SetOptional(.T.)
	
	oStruSFE:SetProperty('*' , MODEL_FIELD_OBRIGAT,	.F.)

	oStruSFE:SetProperty('FE_ORDPAGO', MODEL_FIELD_VALUES , "") 

	//Evento del Modelo
	oModel:InstallEvent("FINV999PAR","FINV999",oMdlEvent)
	oModel:InstallEvent("F999RETPAR",/*cOwner*/,oRetEvent)
	
Return oModel

/*/{Protheus.doc} ViewDef
	Interface del modelo de datos
	@type 		Function
	@author 	carlos.espinoza
	@since 		16/05/2025
	@version	12.1.2310 / Superior
	@return		Object, Vista del Modelo de dados
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)
Local oModel    := Nil

	oModel := oView:GetModel()

Return oView
