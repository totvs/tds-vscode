#INCLUDE 'protheus.ch'
#INCLUDE 'parmtype.ch'
#INCLUDE 'FWMVCDEF.CH'

#DEFINE SOURCEFATHER "FINA887"

/*/{Protheus.doc} FINA887CHI
Fonte de cobros diversos (Chile)
@author 	raul.medina
@since 		25/05/2021
@version	12.1.27 / Superior
/*/
Function FINA887CHI()
Local oBrowse := Nil
	
	oBrowse := BrowseDef()
	
	oBrowse:Activate()
	
Return nil

/*/{Protheus.doc} BrowseDef
Definici�n de Browse
@author	 	raul.medina
@since 		25/05/2021
@version	12.1.27 / Superior
/*/
Static Function BrowseDef() 
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
Define las operaciones que ser�n realizadas por la aplicaci�n
@author 	raul.medina
@since 		25/05/2021
@version	12.1.27 / Superior
/*/
Static Function ModelDef()
Local oModel		:= FwLoadModel(SOURCEFATHER)
Local oModelSEL 	:= oModel:GetModel( 'SEL_DETAIL' )
Local oStruSEL		:= oModelSEL:oFormModelStruct
Local oStruRET		:= FWFormModelStruct():New()
Local oEvtTit		:= F887FINCHI():New()
	
	oStruSEL:SetProperty( 'EL_TIPODOC'	, 	MODEL_FIELD_TAMANHO ,2	 ) 
	
	oStruSEL:SetProperty( 'EL_DIACTB'	, 	MODEL_FIELD_WHEN ,	{|oModelGrid| .T. } ) //?
	
	oModel:InstallEvent("F887FINCHI", "F887FIN", oEvtTit)

Return oModel

/*/{Protheus.doc} ViewDef
Interfce del modelo de datos de Cobros Diversos para localizaci�n Chile
@return		oView objeto del View
@author 	raul.medina
@since 		12/2024
@version	12.1.2210 / Superior
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)

	oView:GetViewObj("VIEW_SEL")[3]:oStructView:RemoveField( "EL_TIPO" )
	
Return oView
