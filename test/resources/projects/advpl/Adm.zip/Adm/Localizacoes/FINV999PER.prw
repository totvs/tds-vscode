#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} FINV999PER
	Clase responsable por el evento de reglas de negocio de localizaci�n Peru
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/10/2025
/*/
Class FINV999PER From FwModelEvent 

	Method New() CONSTRUCTOR

	Method VldActivate()

EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/10/2025
/*/
Method New() Class FINV999PER
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/10/2025
/*/
Method VldActivate(oModel) Class FINV999PER
Local lRet			:= .T.

	self:GetEvent("FINV999"):lCkPg := .T.

Return lRet
