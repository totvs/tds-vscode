#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'fina999.ch'

#DEFINE SOURCEFATHER "FINA999"

/*/{Protheus.doc} FINA999MEX
	Fuente de Modelo de Datos de Orden de Pago Localizado para M�xico
	@type Function
	@author 	arodriguez
	@since 		29/06/2025
	@version	12.1.2310 / Superior
/*/
Function FINA999MEX()
Local oBrowse	:= Nil

	oBrowse := BrowseDef()
	oBrowse:Activate()
	
Return Nil

/*/{Protheus.doc} BrowseDef
	Definici�n de Browse
	@type Function
	@author	 	arodriguez
	@since 		29/06/2025
	@version	12.1.2310 / Superior
/*/
Static Function BrowseDef()
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
	Define las operaciones que ser�n realizadas por la aplicaci�n
	@type Function
	@author 	arodriguez
	@since 		29/06/2025
	@version	12.1.2310 / Superior
/*/
Static Function MenuDef()
Local aRotina := {}
	
aRotina := FWLoadMenuDef(SOURCEFATHER)

Return aRotina

/*/{Protheus.doc} ModelDef
	Defini��o do modelo de Dados
	@type Function
	@author 	arodriguez
	@since 		29/06/2025
	@version	12.1.2310 / Superior
	@return		Object, Modelo de dados
/*/
Static Function ModelDef()
Local oModel		:= FwLoadModel(SOURCEFATHER)
Local oStruFJR		:= oModel:GetModel('FJR_MASTER'):GetStruct()
Local oMdlEvent		:= FINV999MEX():New()
Local oFinEvent		:= F999FINMEX():New()
Local oRetEvent		:= F999RETMEX():New()
Local oPAEvent		:= F999PAMEX():New()

	oStruFJR:AddField(STR0039	, STR0039	, 'DCONCEP'	, 'C' , 255) // "Desc. Conc."

	//Evento del Modelo
	oModel:InstallEvent("FINV999MEX","FINV999",oMdlEvent)
	oModel:InstallEvent("F999FINMEX","F999FIN",oFinEvent)
	oModel:InstallEvent("F999RETMEX",/*cOwner*/,oRetEvent)
	oModel:InstallEvent("F999PAMEX" ,"F999PA" ,oPAEvent)

Return oModel

/*/{Protheus.doc} ViewDef
	Interface del modelo de datos
	@type Function
	@author 	arodriguez
	@since 		16/05/2025
	@version	12.1.2310 / Superior
	@return		Object, Vista del Modelo de dados
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)
Local oModel    := Nil

	oModel := oView:GetModel()

Return oView
