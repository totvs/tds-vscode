#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'
#include 'fwlibversion.ch'

/*/{Protheus.doc} F999RETPAR
	Clase responsable por el evento de reglas de negocio de retenci�n de Paraguay
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999RETPAR From FwModelEvent 

	DATA cUniao   As Character

	DATA cAgente  As Character

	DATA cDepart  As Character

	DATA aSE2Imp  As Array

	DATA lF850Ret As Logical

	Method New() CONSTRUCTOR
	
	Method VldActivate()

	Method BeforeTTS()

	Method AfterTTS()

	Method F999UPDRET()

	Method UPDRETIVA()

	Method UPDRETIR()

	Method F999GravTX()

	Method F999GerVen()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999RETPAR
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param      oModel, Object, Modelo de dados
/*/
Method VldActivate(oModel) Class F999RETPAR
Local lRet			:= .T.
Local nOperation	:= oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT

		self:cUniao   := Padr(SuperGetMv("MV_UNIAO",.F.,""),GetSx3Cache("A2_COD","X3_TAMANHO"))

		self:cAgente  := SuperGetMv("MV_AGENTE",.F.,"NNNNNN")
		
		self:cDepart  := SuperGetMv("MV_DEPART",.F., "")

		self:lF850Ret := ExistBlock("A085ARET")

	EndIf

Return lRet

/*/{Protheus.doc} BeforeTTS
	Metodo responsabe por ejecutar reglas de negocio genericas antes de la transacci�n
	del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza	
	@version	12.2.2310 / Superior
	@since		09/01/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method BeforeTTS(oModel, cModelId) Class F999RETPAR
Local nOperation := oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT
		self:aSE2Imp := {}
		self:F999UPDRET(oModel)
	EndIf     	

Return

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio de retenciones 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		26/08/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method AfterTTS(oModel, cModelId) Class F999RETPAR
Local nOperation	:= oModel:GetOperation()
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')
Local oJImp 		:= JsonObject():New()

	If nOperation == MODEL_OPERATION_INSERT .And. !oModelEOP:GetValue("HASERROR")

		If self:lF850Ret
			oJImp['I']  := {"IV-","IVA"}
			oJImp['R']  := {"IR-","IRI"}
			F999PERet(oModelSFE, oJImp, "A085ARET")
		EndIf
		
		If !oModelEOP:GetValue("PA")
			self:F999GravTX()
		EndIf

	EndIf

	FreeObj(oJImp)
	self:aSE2Imp := {}

Return Nil

/*/{Protheus.doc} F999UPDRET
	Metodo responsable por realizar las actualizaciones en el modelo de retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2025 
	@param      oModel, Object, Modelo de dados
/*/
Method F999UPDRET(oModel) Class F999RETPAR
Local nTamNum	:= GetSx3Cache("EK_NUM","X3_TAMANHO")
Local nTamMoe	:= GetSx3Cache("EK_MOEDA","X3_TAMANHO")
Local cFilSFE	:= xFilial("SFE")
Local cFilSEK	:= xFilial("SEK")

Default oModel := Nil

	self:UPDRETIVA(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

	self:UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

Return Nil

/*/{Protheus.doc} UPDRETIVA
	Funci�n que se encarga de actualizar las retenciones de IVA en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Method UPDRETIVA(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK) Class F999RETPAR
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local oModelSE2 	:= oModel:GetModel('SE2_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""
Local lSeekSE2		:= .F.
Local nValor        := 0
Local nRetenc		:= 0
Local nPos			:= 0

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "I" .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 
			lSeekSE2 := oModelSE2:SeekLine({{"E2_NUM", oModelSFE:GetValue("FE_NFISCAL")}}, .F., .T.) 

			If lSeekSE2 .And. (oModelSFE:GetValue("FE_VALBASE") != 0 .Or. (oModelSFE:GetValue("FE_RETENC") == 0 .And. oModelSE2:GetValue("E2_TIPO") == "NCP"))
				cNroCert  := F999GetCert("IVA   ", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"IVA", .F.)
				oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
				If oModelSFE:GetValue("FE_VALIMP") <> 0
					oModelSFE:LoadValue("FE_NROCERT", cNroCert)
				Else
					oModelSFE:LoadValue("FE_NROCERT", "NORET")
				EndIf
				oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
				oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
				oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))
				nRetenc := oModelSFE:GetValue("FE_RETENC")
				oModelSFE:LoadValue("FE_RETENC"	, oModelSFE:GetValue("FE_VALIMP"))

				If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
					oModelTTB:AddLine()
				EndIf

				nValor := Round(xMoeda(oModelSFE:GetValue("FE_VALIMP"),1,oModelFJR:GetValue("NMOERET"),,3,,oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET"))),MsDecimais(oModelFJR:GetValue("NMOERET")))
				If nValor <> 0
					oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
					oModelTTB:LoadValue("EK_TIPODOC", "RG")
					oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
					oModelTTB:LoadValue("EK_TIPO"	, "IV-")
					oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
					oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_VALIMP")) 
					oModelTTB:LoadValue("EK_VALOR"	, nValor)
					oModelTTB:LoadValue("EK_SALDO"	, nValor)
					oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
					oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
					oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
					oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
					oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
					oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
					oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
					oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
					oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
					
					F999GrvTx(,,,, oModelMOE, oModelTTB)
				EndIf

				F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, nRetenc)

				nPos := AScan(self:aSE2Imp,{ |x| x[1] == oModelSFE:GetValue("FE_ORDPAGO") .And. x[2] == "I"})
				If nPos == 0
					AADD(self:aSE2Imp, {;
						oModelSFE:GetValue("FE_ORDPAGO"),;
						oModelSFE:GetValue("FE_TIPO"),;
						oModelSFE:GetValue("FE_VALIMP"),;
						oModelSFE:GetValue("FE_FORNECE"),;
						oModelSFE:GetValue("FE_LOJA"),;
						nValor;
					})
				Else
					self:aSE2Imp[nPos][3] := self:aSE2Imp[nPos][3] + oModelSFE:GetValue("FE_VALIMP")
				EndIf
			EndIf
		EndIf
	Next

Return Nil

/*/{Protheus.doc} UPDRETIR
	Funci�n que se encarga de actualizar las retenciones de IR en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Method UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK) Class F999RETPAR
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""
Local nPos			:= 0

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "R" .And. oModelSFE:GetValue("FE_RETENC") != 0 .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 

			cNroCert  := F999GetCert("IR  ", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"IR", .F.)
			oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
			oModelSFE:LoadValue("FE_NROCERT", cNroCert)
			oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
			oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
			oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))

			If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
				oModelTTB:AddLine()
			EndIf

			oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
			oModelTTB:LoadValue("EK_TIPODOC", "RG")
			oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
			oModelTTB:LoadValue("EK_TIPO"	, "IR-")
			oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
			oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_RETENC")) 
			oModelTTB:LoadValue("EK_VALOR"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_SALDO"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
			oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
			oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
			oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
			oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
			
			If oModelTTB:HasField("EK_NROCERT")
				oModelTTB:LoadValue("EK_NROCERT", cNroCert)
			EndIf
			
			F999GrvTx(,,,, oModelMOE, oModelTTB)

			F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, oModelSFE:GetValue("FE_RETENC"))

			nPos := AScan(self:aSE2Imp,{ |x| x[1] == oModelSFE:GetValue("FE_ORDPAGO") .And. x[2] == "R"})
			If nPos == 0
				AADD(self:aSE2Imp, {;
					oModelSFE:GetValue("FE_ORDPAGO"),;
					oModelSFE:GetValue("FE_TIPO"),;
					oModelSFE:GetValue("FE_VALIMP"),;
					oModelSFE:GetValue("FE_FORNECE"),;
					oModelSFE:GetValue("FE_LOJA"),;
					oModelSFE:GetValue("FE_VALIMP");
				})
			Else
				self:aSE2Imp[nPos][3] := self:aSE2Imp[nPos][3] + oModelSFE:GetValue("FE_VALIMP")
			EndIf
		EndIf
	Next

Return Nil

/*/{Protheus.doc} F999GravTX
	Metodo responsable por realizar los grabados de t�tulos financieros de tipo TX por retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		04/09/2026 
/*/
Method F999GravTX() Class F999RETPAR
Local cFilSA2		:= xFilial("SA2")
Local cLojaImp  	:= PadR("00", GetSx3Cache("A2_LOJA","X3_TAMANHO"), "0")
Local cParcela 		:= PadR("0", GetSx3Cache("E2_PARCELA","X3_TAMANHO"), "")
Local cPrefixo		:= ""
Local aArea			:= GetArea()
Local nX 			:= 0

	// Crea proveedor en caso de que no exista
	DbSelectArea("SA2")
	SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
	If !SA2->(MsSeek(cFilSA2+self:cUniao))
		Reclock("SA2",.T.)
		SA2->A2_FILIAL 	:= cFilSA2
		SA2->A2_COD    	:= self:cUniao
		SA2->A2_NOME	:= STR0079 //UNIAO
		SA2->A2_NREDUZ 	:= STR0079 //UNIAO
		SA2->A2_LOJA	:= cLojaImp
		SA2->A2_MUN 	:= "."
		SA2->A2_EST 	:= self:cDepart
		SA2->A2_BAIRRO  := "."
		SA2->A2_END 	:= "."
		SA2->A2_TIPO	:= "J"
		SA2->(MsUnLock())
	EndIf

	For nX := 1 To Len(self:aSE2Imp)
		If self:aSE2Imp[nX][3] > 0
			cPrefixo := ""
			If SA2->(MsSeek(cFilSA2+self:aSE2Imp[nX][4]+self:aSE2Imp[nX][5]))
				If SA2->A2_PAIS <> "586" .And. !Empty(SA2->A2_PAIS)
					cPrefixo := "EXT" // Fornecedor do tipo exterior
				ElseIf (Subs(self:cAgente,1,1) == "E")
					cPrefixo :="EXP"  // Agente Exportador
				ElseIf (Subs(self:cAgente,1,1) == "D")
					cPrefixo :="DES"  // Agente Designado
				EndIf
			EndIf

			cParcela := Soma1(cParcela)
			RecLock("SE2",.T.)
			SE2->E2_FILIAL 	:= xFilial("SE2")
			SE2->E2_NUM		:= self:aSE2Imp[nX][1]
			SE2->E2_PARCELA := cParcela
			SE2->E2_EMISSAO	:= dDataBase
			SE2->E2_VALOR	:= self:aSE2Imp[nX][3]
			SE2->E2_SALDO	:= self:aSE2Imp[nX][3]
			SE2->E2_NATUREZ	:= SA2->A2_NATUREZ
			SE2->E2_TIPO	:= "TX"
			SE2->E2_NOMFOR  := "UNIAO"
			SE2->E2_PREFIXO	:= cPrefixo
			SE2->E2_FORNECE := self:cUniao
			SE2->E2_LOJA	:= cLojaImp
			SE2->E2_EMIS1	:= dDataBase
			SE2->E2_VLCRUZ 	:= self:aSE2Imp[nX][6]
			SE2->E2_MOEDA	:= 1
			SE2->E2_ORDPAGO := self:aSE2Imp[nX][1]
			SE2->E2_ORIGEM	:= "FINA085A"
			SE2->E2_FILORIG := cFilAnt

			If self:aSE2Imp[nX][2] == "I"
				SE2->E2_VENCTO 	:= self:F999GerVen()
				SE2->E2_HIST	:= STR0080 //Ret. IVA
			Else
				SE2->E2_VENCTO 	:= self:F999GerVen(cPrefixo,"R")
				SE2->E2_HIST	:= STR0081 //Ret. Impuesto de Renta
			EndIf

			SE2->E2_VENCREA	:= DataValida(SE2->E2_VENCTO)
			SE2->(MsUnLock())
		EndIf
	Next

	RestArea(aArea)

Return Nil

/*/{Protheus.doc} F999GerVen
	Metodo responsable obtener la fecha de vencimiento
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		04/09/2026 
	@param		cPrefixo, Character, Prefijo
	@param	 	cImp, Character, Impuesto
	@return 	Date, Fecha de vencimiento
/*/
Method F999GerVen(cPrefixo, cImp) Class F999RETPAR
Local nTamRuc		:= Len(SM0->M0_CGC)
Local dDataVenc		:= Ctod("//")
Local cDigRuc		:= Subs(SM0->M0_CGC,nTamRuc,1)
Local nDigRuc       := 0
Local cVal 			:= ""
Local nMonth        := Month(dDataBase)
Local nYear         := Year(dDataBase)

Default cPrefixo	:= ""
Default cImp		:= ""

	If Month(dDataBase) == 12
		nMonth := 01
		nYear  := Year(dDataBase)+1
	EndIf

	If cPrefixo == "EXT" .And. cImp == "R"
		dDataVenc := Stod(StrZero(nYear,4)+StrZero(nMonth,2)+"30")
	Else
		nDigRuc   := VAL(cDigRuc)
		cVal      := StrZero((7 + nDigRuc * 2),2)
		dDataVenc := Stod(StrZero(nYear,4)+StrZero(nMonth,2)+cVal)
	EndIf

Return(dDataVenc)
