#INCLUDE 'protheus.ch'
#INCLUDE 'parmtype.ch'
#INCLUDE 'FWMVCDEF.CH'

#DEFINE SOURCEFATHER "FINA887"

/*/{Protheus.doc} FINA887URU
Fonte de cobros diversos (Uruguay)
@author 	eduardo.manriquez
@since 		01/08/2022
@version	12.1.27 / Superior
/*/
Function FINA887URU()
Local oBrowse := Nil
	
	oBrowse := BrowseDef()
	
	oBrowse:Activate()
	
Return nil

/*/{Protheus.doc} BrowseDef
Definici�n de Browse
@author 	eduardo.manriquez
@since 		01/08/2022
@version	12.1.27 / Superior
/*/
Static Function BrowseDef() 
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
Define las operaciones que ser�n realizadas por la aplicaci�n
@author 	eduardo.manriquez
@since 		01/08/2022
@version	12.1.27 / Superior
/*/
Static Function ModelDef()
	Local oModel		:= FwLoadModel(SOURCEFATHER)
	Local oEvtDifCam	:= F887DIFCAM():New()

	oModel:InstallEvent("F887DIFCAM",/*cOwner*/,oEvtDifCam)

Return oModel

/*/{Protheus.doc} ViewDef
Interfce del modelo de datos de Cobros Diversos para localizaci�n Uruguay
@return		oView objeto del View
@author 	raul.medina
@since 		12/2024
@version	12.1.2210 / Superior
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)

	oView:GetViewObj("VIEW_SEL")[3]:oStructView:RemoveField( "EL_TIPO" )
	
Return oView
