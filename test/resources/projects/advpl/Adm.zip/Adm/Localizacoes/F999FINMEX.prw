#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} F999FINMEX
	Clase responsable por el evento de reglas de negocio de localizaci�n padr�n
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999FINMEX From FwModelEvent 

	Method New() CONSTRUCTOR
	
	Method VldActivate()

EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999FINMEX
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method VldActivate(oModel) Class F999FINMEX
Local lRet			:= .T.
	
	self:GetEvent("F999FIN"):lMsFil    := .T.

Return lRet
