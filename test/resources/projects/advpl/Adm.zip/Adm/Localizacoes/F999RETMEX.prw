#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'
#include 'fwlibversion.ch'

/*/{Protheus.doc} F999RETMEX
	Clase responsable por el evento de reglas de negocio de retenci�n de M�xico
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026
/*/
Class F999RETMEX From FwModelEvent 

	DATA lCalcRt As Logical
	
	Method New() CONSTRUCTOR
	
	Method VldActivate()

	Method BeforeTTS()

	Method InTTS()

	Method F999UPDRET()

	Method F999GRVRET()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026
/*/
Method New() Class F999RETMEX
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026
	@param      oModel, Object, Modelo de dados
/*/
Method VldActivate(oModel) Class F999RETMEX
Local lRet		:= .T.
Local oModelSE2 := oModel:GetModel('SE2_DETAIL')
Local oModelTTB := oModel:GetModel('TTB_DETAIL')

	self:lCalcRt := oModelTTB:HasField("EK_VALIMP1") .And. oModelSE2:HasField("E2_VALIMP1")

Return lRet

/*/{Protheus.doc} BeforeTTS
	Metodo responsabe por ejecutar reglas de negocio genericas antes de la transacci�n
	del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza	
	@version	12.2.2310 / Superior
	@since		18/08/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method BeforeTTS(oModel, cModelId) Class F999RETMEX
Local nOperation := oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT .And. self:lCalcRt
		self:F999UPDRET(oModel)
	EndIf     	

Return

/*/{Protheus.doc} InTTS
	Metodo responsable por ejecutar reglas de negocio genericas 
	dentro de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method InTTS(oModel, cModelId) Class F999RETMEX
Local nOperation	:= oModel:GetOperation()
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')

	If nOperation == MODEL_OPERATION_INSERT .And. self:lCalcRt .And. !oModelEOP:GetValue("HASERROR")
		self:F999GRVRET(oModel)
	EndIf

Return Nil

/*/{Protheus.doc} F999UPDRET
	Metodo responsable por realizar las actualizaciones en el modelo de retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026
	@param      oModel, Object, Modelo de dados
/*/
Method F999UPDRET(oModel) Class F999RETMEX
Local oModelSE2 := oModel:GetModel('SE2_DETAIL')
Local oModelTTB := oModel:GetModel('TTB_DETAIL')
Local nX 		:= 0
Local nI		:= 0
Local cI        := ""
Local aAreaSE2  := {}
Local nValorBx  := 0
Local nPerBx    := 0
Local nPerDesc  := 0
Local nValorDc  := 0
Local nBaseBx   := 0
Local nAliqBx   := 0
Local nVlImp    := 0

For nX := 1 To oModelTTB:Length()
	oModelTTB:GoLine(nX)

	If oModelTTB:GetValue("EK_TIPODOC") == "TB" .And. ;
		oModelSE2:SeekLine({;
		{"E2_NUM", oModelTTB:GetValue("EK_NUM")},;
		{"E2_PARCELA", oModelTTB:GetValue("EK_PARCELA")},;
		{"E2_TIPO", oModelTTB:GetValue("EK_TIPO")},;
		{"E2_PREFIXO", oModelTTB:GetValue("EK_PREFIXO")},;
		{"E2_FORNECE", oModelTTB:GetValue("EK_FORNECE")},;
		{"E2_LOJA", oModelTTB:GetValue("EK_LOJA")}}, .F., .T.) 

		If oModelSE2:GetValue("RECNO") > 0

			aAreaSE2 := SE2->(GetArea())
			SE2->(MsGoTo(oModelSE2:GetValue("RECNO")))

			nPerBx   := (oModelTTB:GetValue("EK_VALOR") * 100) / SE2->E2_VALOR
			nPerDesc := (oModelTTB:GetValue("EK_DESCONT") * 100) / SE2->E2_VALOR

			For nI := 1 To 6
				cI := Alltrim(STR(nI))
				nVlImp   := &("SE2->E2_VALIMP"+cI)
				If nVlImp > 0
					nValorBx := nVlImp * (nPerBx / 100)
					nBaseBx  := &("SE2->E2_BASIMP"+cI) * (nPerBx / 100)
					nAliqBx  := &("SE2->E2_ALQIMP"+cI)
					nValorDc := nVlImp * (nPerDesc / 100)

					If oModelTTB:HasField("EK_VALIMP"+cI)
						oModelTTB:LoadValue("EK_VALIMP"+cI, nValorBx)
					EndIf

					If oModelTTB:HasField("EK_BASIMP"+cI)
						oModelTTB:LoadValue("EK_BASIMP"+cI, nBaseBx)
					EndIf

					If oModelTTB:HasField("EK_ALQIMP"+cI)
						oModelTTB:LoadValue("EK_ALQIMP"+cI, nAliqBx)
					EndIf
				
					If oModelTTB:HasField("EK_IMPDES"+cI)
						oModelTTB:LoadValue("EK_IMPDES"+cI, nValorDc)
					EndIf
				EndIf
			Next 

			RestArea(aAreaSE2)
		EndIf
	EndIf
Next

Return Nil

/*/{Protheus.doc} F999GRVRET
	Metodo responsable por realizar las operaciones de grabado relacionadas al proceso de retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2026
	@param      oModel, Object, Modelo de dados
/*/
Method F999GRVRET(oModel) Class F999RETMEX
Local oModelSE2 := oModel:GetModel('SE2_DETAIL')
Local oModelTTB := oModel:GetModel('TTB_DETAIL')
Local nX 		:= 0
Local nI		:= 0
Local cI        := ""
Local aAreaSE2  := {}
Local aAreaSE5  := {}

For nX := 1 To oModelTTB:Length()
	oModelTTB:GoLine(nX)

	If oModelTTB:GetValue("EK_TIPODOC") == "TB" .And. ;
		oModelSE2:SeekLine({;
		{"E2_NUM", oModelTTB:GetValue("EK_NUM")},;
		{"E2_PARCELA", oModelTTB:GetValue("EK_PARCELA")},;
		{"E2_TIPO", oModelTTB:GetValue("EK_TIPO")},;
		{"E2_PREFIXO", oModelTTB:GetValue("EK_PREFIXO")},;
		{"E2_FORNECE", oModelTTB:GetValue("EK_FORNECE")},;
		{"E2_LOJA", oModelTTB:GetValue("EK_LOJA")}}, .F., .T.) 

		If oModelSE2:GetValue("RECNO") > 0 .And. oModelSE2:GetValue("RECSE5") > 0

			aAreaSE2 := SE2->(GetArea())
			aAreaSE5 := SE5->(GetArea())
			SE2->(MsGoTo(oModelSE2:GetValue("RECNO")))
			SE5->(MsGoTo(oModelSE2:GetValue("RECSE5")))

			RecLock("SE5", .F.)

			For nI := 1 To 6
				cI := Alltrim(STR(nI))
				If SE5->(ColumnPos("E5_VALIMP"+cI)) > 0 .And. oModelTTB:HasField("EK_VALIMP"+cI)
					SE5->&("E5_VALIMP"+cI) := oModelTTB:GetValue("EK_VALIMP"+cI)
				EndIf

				If SE5->(ColumnPos("E5_BASIMP"+cI)) > 0 .And. oModelTTB:HasField("EK_BASIMP"+cI)
					SE5->&("E5_BASIMP"+cI) := oModelTTB:GetValue("EK_BASIMP"+cI)
				EndIf

				If SE5->(ColumnPos("E5_ALQIMP"+cI)) > 0 .And. oModelTTB:HasField("EK_ALQIMP"+cI)
					SE5->&("E5_ALQIMP"+cI) := oModelTTB:GetValue("EK_ALQIMP"+cI)
				EndIf
			Next 

			SE5->(MsUnlock())

			RestArea(aAreaSE5)
			RestArea(aAreaSE2)
		EndIf
	EndIf
Next

Return Nil
