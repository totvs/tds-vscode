#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'
#include 'fwlibversion.ch'

/*/{Protheus.doc} F999RETPER
	Clase responsable por el evento de reglas de negocio de retenci�n de Per�
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999RETPER From FwModelEvent 

	DATA cUniao     As Character

	DATA cSeriec    As Character

	DATA cSerie2    As Character

	DATA aSE2Imp    As Array

	DATA lFR0Chv    As Logical

	DATA lF850Ret   As Logical

	DATA lGerTitRet As Logical

	Method New() CONSTRUCTOR
	
	Method VldActivate()

	Method BeforeTTS()

	Method AfterTTS()

	Method F999UPDRET()

	Method UPDRETIGV()

	Method UPDRETIR()

	Method F999GravTX()

	Method F999GerVen()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999RETPER
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param      oModel, Object, Modelo de dados
/*/
Method VldActivate(oModel) Class F999RETPER
Local lRet			:= .T.
Local nOperation	:= oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT

		self:cUniao     := Padr(SuperGetMv("MV_UNIAO",.F.,""),GetSx3Cache("A2_COD","X3_TAMANHO"))

		self:cSeriec    := SuperGetMv("MV_SERETEN",.F.,"")

		self:cSerie2    := SuperGetMv("MV_CRSERIE",.F.,"")

		self:lFR0Chv    := FindFunction("FR0CHAVE")

		self:lF850Ret   := ExistBlock("A085ARET")

		self:lGerTitRet := SuperGetMv("MV_TITRET",.T.,.F.)

	EndIf

Return lRet

/*/{Protheus.doc} BeforeTTS
	Metodo responsabe por ejecutar reglas de negocio genericas antes de la transacci�n
	del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza	
	@version	12.2.2310 / Superior
	@since		09/01/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method BeforeTTS(oModel, cModelId) Class F999RETPER
Local nOperation := oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT
		self:aSE2Imp := {}
		self:F999UPDRET(oModel)
	EndIf     	

Return

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio de retenciones 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		26/08/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method AfterTTS(oModel, cModelId) Class F999RETPER
Local nOperation	:= oModel:GetOperation()
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')
Local oJImp 		:= JsonObject():New()

	If nOperation == MODEL_OPERATION_INSERT .And. !oModelEOP:GetValue("HASERROR")

		If self:lF850Ret
			oJImp['I']  := {"IG-","IGV"}
			oJImp['R']  := {"IR-","ISR"}
			F999PERet(oModelSFE, oJImp, "A085ARET")
		EndIf

		If self:lGerTitRet
			self:F999GravTX()
		EndIf

	EndIf

	FreeObj(oJImp)
	self:aSE2Imp := {}

Return Nil

/*/{Protheus.doc} F999UPDRET
	Metodo responsable por realizar las actualizaciones en el modelo de retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2025 
	@param      oModel, Object, Modelo de dados
/*/
Method F999UPDRET(oModel) Class F999RETPER
Local nTamNum	:= GetSx3Cache("EK_NUM","X3_TAMANHO")
Local nTamMoe	:= GetSx3Cache("EK_MOEDA","X3_TAMANHO")
Local cFilSFE	:= xFilial("SFE")
Local cFilSEK	:= xFilial("SEK")

Default oModel := Nil

	self:UPDRETIGV(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

	self:UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

Return Nil

/*/{Protheus.doc} UPDRETIGV
	Funci�n que se encarga de actualizar las retenciones de IGV en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Method UPDRETIGV(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK) Class F999RETPER
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""
Local nValor 		:= 0
Local nPos			:= 0

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "I" .And. oModelSFE:GetValue("FE_RETENC") != 0 .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 

			cNroCert  := F999GetCert("IGV   ", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"IGV")
			oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
			oModelSFE:LoadValue("FE_NROCERT", cNroCert)
			oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
			oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
			oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))
			oModelSFE:LoadValue("FE_SERIEC"	, self:cSeriec)

			If oModelSFE:HasField("FE_SERIE2")
				oModelSFE:LoadValue("FE_SERIE2"	, self:cSerie2)
			EndIf

			If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
				oModelTTB:AddLine()
			EndIf

			nValor := Round(xMoeda(oModelSFE:GetValue("FE_RETENC"),1,oModelFJR:GetValue("NMOERET"),,3,,oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET"))),MsDecimais(oModelFJR:GetValue("NMOERET")))

			oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
			oModelTTB:LoadValue("EK_TIPODOC", "RG")
			oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
			oModelTTB:LoadValue("EK_TIPO"	, "IG-")
			oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
			oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_RETENC")) 
			oModelTTB:LoadValue("EK_VALOR"	, nValor)
			oModelTTB:LoadValue("EK_SALDO"	, nValor)
			oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
			oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
			oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
			oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
			oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
			
			F999GrvTx(,,,, oModelMOE, oModelTTB)

			F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, oModelSFE:GetValue("FE_RETENC"))

			nPos := AScan(self:aSE2Imp,{ |x| x[1] == oModelSFE:GetValue("FE_ORDPAGO") .And. x[2] == "I"})
			If nPos == 0
				AADD(self:aSE2Imp, {;
					oModelSFE:GetValue("FE_ORDPAGO"),;
					oModelSFE:GetValue("FE_TIPO"),;
					oModelSFE:GetValue("FE_VALIMP");
				})
			Else
				self:aSE2Imp[nPos][3] := self:aSE2Imp[nPos][3] + oModelSFE:GetValue("FE_VALIMP")
			EndIf
		EndIf
	Next

Return Nil

/*/{Protheus.doc} UPDRETIR
	Funci�n que se encarga de actualizar las retenciones de IR en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Method UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK) Class F999RETPER
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""
Local nValor		:= 0
Local nPos			:= 0

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "R" .And. oModelSFE:GetValue("FE_RETENC") != 0 .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 

			cNroCert  := F999GetCert("ISRPER", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"ISRPER")
			oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
			oModelSFE:LoadValue("FE_NROCERT", cNroCert)
			oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
			oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
			oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))
			oModelSFE:LoadValue("FE_SERIEC"	, self:cSeriec)

			If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
				oModelTTB:AddLine()
			EndIf

			nValor := Round(xMoeda(oModelSFE:GetValue("FE_RETENC"),1,oModelFJR:GetValue("NMOERET"),,3,,oModelMOE:GetValue("TASA",oModelFJR:GetValue("NMOERET"))),MsDecimais(oModelFJR:GetValue("NMOERET")))

			oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
			oModelTTB:LoadValue("EK_TIPODOC", "RG")
			oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
			oModelTTB:LoadValue("EK_TIPO"	, "IR-")
			oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
			oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_RETENC")) 
			oModelTTB:LoadValue("EK_VALOR"	, nValor)
			oModelTTB:LoadValue("EK_SALDO"	, nValor)
			oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
			oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
			oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
			oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
			oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
			
			F999GrvTx(,,,, oModelMOE, oModelTTB)

			F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, oModelSFE:GetValue("FE_RETENC"))

			nPos := AScan(self:aSE2Imp,{ |x| x[1] == oModelSFE:GetValue("FE_ORDPAGO") .And. x[2] == "R"})
			If nPos == 0
				AADD(self:aSE2Imp, {;
					oModelSFE:GetValue("FE_ORDPAGO"),;
					oModelSFE:GetValue("FE_TIPO"),;
					oModelSFE:GetValue("FE_VALIMP");
				})
			Else
				self:aSE2Imp[nPos][3] := self:aSE2Imp[nPos][3] + oModelSFE:GetValue("FE_VALIMP")
			EndIf
		EndIf
	Next

Return Nil

/*/{Protheus.doc} F999GravTX
	Metodo responsable por realizar los grabados de t�tulos financieros por retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/09/2026 
/*/
Method F999GravTX() Class F999RETPER
Local cFilSA2		:= xFilial("SA2")
Local cLojaImp  	:= PadR("00", GetSx3Cache("A2_LOJA","X3_TAMANHO"), "0")
Local cParcela 		:= PadR("0", GetSx3Cache("E2_PARCELA","X3_TAMANHO"), "")
Local aArea			:= GetArea()
Local nX 			:= 0

	// Crea proveedor en caso de que no exista
	DbSelectArea("SA2")
	SA2->(DbSetOrder(1)) //A2_FILIAL+A2_COD+A2_LOJA
	If !SA2->(MsSeek(cFilSA2+self:cUniao))
		Reclock("SA2",.T.)
		SA2->A2_FILIAL 	:= cFilSA2
		SA2->A2_COD    	:= self:cUniao
		SA2->A2_NOME	:= STR0079 //UNIAO
		SA2->A2_NREDUZ 	:= STR0079 //UNIAO
		SA2->A2_LOJA	:= cLojaImp
		SA2->A2_MUN 	:= "."
		SA2->A2_EST 	:= "."
		SA2->A2_BAIRRO  := "."
		SA2->A2_END 	:= "."
		SA2->A2_TIPO	:= "J"
		SA2->(MsUnLock())
	EndIf

	For nX := 1 To Len(self:aSE2Imp)
		If self:aSE2Imp[nX][3] > 0

			cParcela := Soma1(cParcela)
			RecLock("SE2",.T.)
			SE2->E2_FILIAL 	:= xFilial("SE2")
			SE2->E2_NUM		:= self:aSE2Imp[nX][1]
			SE2->E2_PARCELA := cParcela
			SE2->E2_EMISSAO	:= dDataBase
			SE2->E2_VALOR	:= self:aSE2Imp[nX][3]
			SE2->E2_SALDO	:= self:aSE2Imp[nX][3]
			SE2->E2_NATUREZ	:= SA2->A2_NATUREZ
			SE2->E2_NOMFOR  := SA2->A2_NREDUZ
			SE2->E2_PREFIXO	:= "  "
			SE2->E2_FORNECE := SA2->A2_COD
			SE2->E2_LOJA	:= SA2->A2_LOJA
			SE2->E2_EMIS1	:= dDataBase
			SE2->E2_VLCRUZ 	:= self:aSE2Imp[nX][3]
			SE2->E2_MOEDA	:= 1
			SE2->E2_ORIGEM	:= "FINA085A"

			If self:aSE2Imp[nX][2] == "I"
				SE2->E2_VENCTO 	:= self:F999GerVen("IG-")
				SE2->E2_HIST	:= STR0082 //Ret. Imp.IGV
				SE2->E2_TIPO	:= "IG-"
			Else
				SE2->E2_VENCTO 	:= self:F999GerVen("IR-")
				SE2->E2_HIST	:= STR0083 //Retenci�n IR
				SE2->E2_TIPO	:= "IR-"
			EndIf

			SE2->E2_VENCORI	:= SE2->E2_VENCTO
			SE2->E2_VENCREA	:= DataValida(SE2->E2_VENCTO)
			SE2->(MsUnLock())
		EndIf
	Next

	RestArea(aArea)

Return Nil

/*/{Protheus.doc} F999GerVen
	Metodo responsable obtener la fecha de vencimiento
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		07/09/2026 
	@param	 	cImp, Character, Impuesto
	@return 	Date, Fecha de vencimiento
/*/
Method F999GerVen(cImp) Class F999RETPER
Local cAux 		:= ""
Local cMsg 		:= ""
Local dDataVenc := Ctod("//")

Default cImp	:= ""

	If self:lFR0Chv
		// Busca una fecha especifica para el impuesto
		cAux := FR0Chave("PE4",Substr(Dtos(dDataBase),1,6),cImp,"01")
		If Empty(cAux)
			// Si no encuentra una fecha especifica, busca una fecha est�ndar de uso general
			cAux := FR0Chave("PE4",Substr(Dtos(dDataBase),1,6),"","01")
		EndIf

		dDataVenc := Ctod(cAux)
		If Empty(dDataVenc)
			dDataVenc := dDataBase
			cMsg += AllTrim(STR0084) //Se asumira la de este pago para el vencimiento de los t�tulos referentes a impuestos y/o retenciones, pues no se un encontr� una fecha v�lida para el per�odo referente a esta orden de pago.
			cMsg += ": " + Strzero(Month(dDataBase),2) + "/" + Strzero(Year(dDataBase),4) + CRLF
			cMsg += AllTrim(STR0085) //Verifique la tabla PE4 en mantenimiento de tablas auxiliares.
			MsgAlert(cMsg, STR0086)  //Atenci�n
		Endif
	Endif

Return (dDataVenc)
