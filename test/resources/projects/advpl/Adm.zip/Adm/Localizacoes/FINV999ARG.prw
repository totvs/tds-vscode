#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'

/*/{Protheus.doc} FINV999ARG
	Clase responsable por el evento de reglas de negocio de localizaci�n padr�n
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class FINV999ARG From FwModelEvent 

	Method New() CONSTRUCTOR
	
	Method VldActivate()
	
	Method ModelPosVld()
	
	Method GridLinePosVld()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class FINV999ARG
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method VldActivate() Class FINV999ARG
Local lRet			:= .T.
	
	//Flag que indica si valida modalidad
	self:GetEvent("FINV999"):lVldMod 	:= .T.

	//Flag que indica si valida la l�nea del modelo 
	self:GetEvent("FINV999"):lVldLin 	:= .F.

Return lRet

/*/{Protheus.doc} ModelPosVld
	M�todo responsable por ejecutar las valida�ioes de las reglas de negocio
	gen�ricas del cadastro antes de la grabaci�n del formulario.
	Si retorna falso, no permite grabar.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param 		oModel, Object, Modelo de dados
	@param 		cModelID, Character, Identificador do sub-modelo
	@return     Logical, Indica si las validaciones fueron satisfactorias
/*/
Method ModelPosVld(oModel,cModelID) Class FINV999ARG
Local lRet 			:= .T. As Logical
Local nOperation	:= oModel:GetOperation() As Numeric
Local nX			:= 0 As Numeric
Local aModosPgo  	:= Fin025Tipo()
Local nMoeda 		:= 1
Local oModelEOP		:= oModel:GetModel("EOP_MASTER") As Object
Local oModelFJR		:= oModel:GetModel("FJR_MASTER") As Object
Local oModelSE2		:= oModel:GetModel("SE2_DETAIL") As Object
Local oModelPAG		:= oModel:GetModel("PAG_DETAIL") As Object

	If nOperation == MODEL_OPERATION_INSERT

		If lRet
			nMoeda := oModelEOP:GetValue("NMOEDA")
			For nX := 1 To oModelFJR:Length()
				If lRet .And. (Empty(oModelFJR:GetValue("FJR_FORNEC",nX)) .Or. Empty(oModelFJR:GetValue("FJR_LOJA",nX)))
					Help(,,STR0040,,STR0056,1, 0 ) //"Aviso" - "Existen pagos sin proveedor. Seleccione el proveedor con F4."
					lRet := .F.
					Exit
				EndIf
				
				If lRet .And. !F999SldOP(oModelFJR:GetValue("NSALDOPGOP",nX), oModelFJR:GetValue("DOCTERPA",nX), nMoeda, oModelEOP:GetValue("PA"))
					lRet := .F.
					Exit
				EndIf

				If lRet .And. !F999VldDes(oModelFJR:GetValue("NVALDESC",nX),oModelFJR:GetValue("NPORDESC",nX))
					lRet := .F.
					Exit
				EndIf
			Next 
		EndIf

		If lRet
			For nX := 1 To oModelSE2:Length()
				If lRet .And. !F999VldDoc(oModelSE2:GetValue("RECNO",nX), oModelEOP:GetValue("PREORD"))
					lRet := .F.
					Exit
				EndIf
			Next 
		EndIf

		If lRet
			For nX := 1 To oModelPAG:Length()
				If Alltrim(oModelPAG:GetValue("EK_TIPO",nX)) == "CH" .And. Empty(oModelPAG:GetValue("EK_TALAO",nX))
					Help(,,STR0040,,STR0045,1, 0 ) //"Aviso" - "Hay formas de pago con cheques propios que no tienen el n�mero del talonario correspondiente."
					lRet := .F.
					Exit
				EndIf

				If lRet .And. Alltrim(oModelPAG:GetValue("EK_TIPO",nX)) <> "CH" .And. !Empty(oModelPAG:GetValue("EK_VALOR",nX)) .And. Empty(oModelPAG:GetValue("EK_NUM",nX))
					Help(,,STR0040,,STR0046,1, 0 ) //"Aviso" - "Hay formas de pago con documento propio que no tienen el n�mero de documento informado."
					lRet := .F.
					Exit
				EndIf

				If lRet .And. !Empty(oModelPAG:GetValue("EK_VALOR",nX)) .And. Empty(oModelPAG:GetValue("EK_VENCTO",nX)) 
					Help(,,STR0040,,STR0047,1, 0 ) //"Aviso" - "Hay formas de pago con documento propio que no tienen fecha de vencimiento informada."
					lRet := .F.
					Exit
				EndIf

				If lRet .And. !F999VldVct(oModelPAG:GetValue("EK_TIPO",nX),oModelPAG:GetValue("EK_EMISSAO",nX),oModelPAG:GetValue("EK_VENCTO",nX), aModosPgo)
					Help(,,STR0040,,STR0048,1, 0 ) //"Aviso" - "Fecha de vencimento calculada/informada inv�lida. Verifique otra forma de c�lculo o informe una fecha v�lida."
					lRet := .F.
					Exit
				EndIf
			Next
		EndIf
	EndIf

Return lRet

/*/{Protheus.doc} GridLinePosVld
	Metodo responsabe por ejecutar reglas de negocio genericas para validaci�n de l�nea.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param 		oModel, Object, Modelo de dados
	@param 		cModelID, Character, Identificador do sub-modelo
	@param 		nLine, Numeric, N�mero de l�nea validada
	@return     Logical, Indica si las validaciones fueron satisfactorias
/*/
Method GridLinePosVld(oSubModel, cModelID, nLine) Class FINV999ARG
Local lRet := .T. As Logical
Local nOperation := oSubModel:GetOperation() As Numeric
Local cFJSTipBco := ""
Local cSA6TipBco := ""

	If nOperation == MODEL_OPERATION_INSERT
		If cModelID == "PAG_DETAIL"
			If lRet .And. !Empty(oSubModel:GetValue("EK_BANCO")) .And. Empty(oSubModel:GetValue("EK_TIPO"))
				Help(,,STR0040,,STR0049,1, 0 ) //"Aviso" - "Informe el tipo de documento."
				lRet := .F.
			EndIf

			If lRet .And. !Empty(oSubModel:GetValue("EK_TIPO")) .And. !Empty(oSubModel:GetValue("EK_BANCO")) .And. !Empty(oSubModel:GetValue("EK_AGENCIA")) .And. !Empty(oSubModel:GetValue("EK_CONTA"))
				cFJSTipBco := GetAdvFVal("FJS","FJS_TIPBCO"	,XFilial("FJS")+oSubModel:GetValue("EK_TIPO"),1,"")
				cSA6TipBco := GetAdvFVal("SA6","A6_TIPBCO"	,XFilial("SA6")+oSubModel:GetValue("EK_BANCO")+oSubModel:GetValue("EK_AGENCIA")+oSubModel:GetValue("EK_CONTA"),1,"")
				If !Empty(cFJSTipBco) .And. (cFJSTipBco <> cSA6TipBco)
					Help(,,STR0040,,STR0050,1, 0 ) //"Aviso" - "Hay un tipo de banco que no es v�lido para el modo de pago en la l�nea."
					lRet := .F.
				EndIf
			EndIf
		EndIf
	EndIf

Return lRet

/*/{Protheus.doc} F999VldVct
	Funci�n que valida las fechas emisi�n y vencimiento de las formas de pago 
	Con respecto a la configuraci�n en la tabla FJS
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		18/08/2025
	@param		cTipo, Character, Tipo de forma de pago 
	@param		dEmissao, Date, Fecha emisi�n
	@param		dVencto, Date, Fecha vencimiento
	@param		aModosPgo, Array, Configuraci�n de las formas de pago
	@return 	Logical, Indica si las validaciones fueron satisfactorias
/*/
Function F999VldVct(cTipo, dEmissao, dVencto, aModosPgo)
Local lRet 		:= .T.
Local nDias     := 0
Local nPos		:= 0
Local cTpInt    := ""
Local cTpVal    := ""

Default cTipo 	  := ""
Default dEmissao  := Ctod("//")
Default dVencto	  := Ctod("//")
Default aModosPgo := {}

nPos   := Ascan(aModosPgo,{|x| x[1] == cTipo})

	If nPos > 0
		cTpInt := Alltrim(aModosPgo[nPos][2])
		cTpVal := Alltrim(aModosPgo[nPos][8])

		Do Case
			Case cTpInt $ MVCHEQUE .And. cTpVal == "2"
				nDias :=  dVencto - dEmissao
				If !((nDias >= 1) .And. (nDias <= 360))
					lRet := .F.
				EndIf
			Case cTpInt $ MVCHEQUE .And. cTpVal == "1" .And. dVencto <> dEmissao
				lRet := .F.
			Case !(cTpInt $ MVCHEQUE) .And. cTpVal == "2" .And. dVencto <= dEmissao
				lRet := .F.
			Case !(cTpInt $ MVCHEQUE) .And. cTpVal == "1" .And. dVencto <> dEmissao
				lRet := .F.
			Case Empty(cTpVal) .And. dVencto < dEmissao
				lRet := .F.
		EndCase
	EndIf

Return lRet

/*/{Protheus.doc} F999VldDoc
	Funci�n que valida si el documento fue dado de baja completamente en otra orden de pago
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		21/08/2025
	@param		nRecno, Character, Recno del t�tulo financiero en la tabla SE2
	@param		lPreOrd, Logical, Indica si la orden de pago es una orden previa
	@return 	Logical, Indica si puede o no utilizar el t�tulo financiero
/*/
Function F999VldDoc(nRecno, lPreOrd)
Local lRet  := .T.
Local aArea := {}
Local lVldPreOk := .F.

Default nRecno  := 0
Default lPreOrd := .F.

	lVldPreOk := IIF(lPreOrd, .F., !Empty(SE2->E2_PREOK))

	aArea := SE2->(GetArea())
	DbSelectArea("SE2") 
	SE2->(DbGoto(nRecno))
	If !SE2->(EOF())
		If lVldPreOk .Or. (!Empty(SE2->E2_ORDPAGO) .And. SE2->E2_SALDO == 0)
			Help(,,STR0040,,STR0044,1, 0 ) //"Aviso" - "Documento utilizado en otra orden de pago."
			lRet := .F.
		EndIf
	EndIf
	RestArea(aArea)

Return lRet


/*/{Protheus.doc} F999SldOP
	Funci�n que valida el saldo de la orden de pago
	@type 		Function
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		02/09/2025
	@param 		nSaldo, Character, Saldo de la orden de pago
	@param 		lGenPa, Logical, Indica si se genera PA por documento de tercero
	@param 		nMoeda, Numeric, Moneda de la orden de pago
	@return 	Logical, Indica si el saldo de la orden de pago es v�lido
/*/
Function F999SldOP(nSaldo, lGenPa, nMoeda, lPA)
Local lRet  := .T.

Default nSaldo := 0
Default lGenPa := .F.
Default nMoeda := 1
Default lPA    := .F.

	nSaldo := Round(nSaldo, MsDecimais(nMoeda))

	If nSaldo != 0 .And. (!(nSaldo < 0 .And. lGenPA) .Or. lPA)
		Help(,,STR0040,,; // "Aviso"
		STR0051 + SuperGetMv("MV_SIMB"+Alltrim(Str(nMoeda))) + ; // "Faltan "
		Alltrim(Transform(nSaldo,PesqPict("SE2","E2_VALOR"))) + ;
		STR0052 + ;   // " o su equivalente en otra moneda, para pagar los t�tulos seleccionados."
		STR0053,1, 0) // " Si desea pagar este valor, modifique en la pesta�a T�tulos el valor por pagar."

		lRet := .F.
	EndIf

Return lRet
