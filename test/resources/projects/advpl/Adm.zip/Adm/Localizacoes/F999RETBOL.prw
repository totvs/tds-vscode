#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'tlpp-object.th'
#include 'fina999.ch'
#include 'fwlibversion.ch'

/*/{Protheus.doc} F999RETBOL
	Clase responsable por el evento de reglas de negocio de retenci�n de Bolivia
	@type 		Class
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Class F999RETBOL From FwModelEvent 

	DATA lF850Ret As Logical

	Method New() CONSTRUCTOR
	
	Method VldActivate()

	Method BeforeTTS()

	Method AfterTTS()

	Method F999UPDRET()
	
EndClass

/*/{Protheus.doc} New
	Metodo responsable de la contrucci�n de la clase.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
/*/
Method New() Class F999RETBOL
	
Return Nil

/*/{Protheus.doc} VldActivate
	Metodo responsable de las validaciones al activar el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		29/07/2025
	@param      oModel, Object, Modelo de dados
/*/
Method VldActivate(oModel) Class F999RETBOL
Local lRet			:= .T.
Local nOperation	:= oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT

		self:lF850Ret := ExistBlock("A085ARET")

	EndIf

Return lRet

/*/{Protheus.doc} BeforeTTS
	Metodo responsabe por ejecutar reglas de negocio genericas antes de la transacci�n
	del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza	
	@version	12.2.2310 / Superior
	@since		09/01/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method BeforeTTS(oModel, cModelId) Class F999RETBOL
Local nOperation := oModel:GetOperation()

	If nOperation == MODEL_OPERATION_INSERT
		self:F999UPDRET(oModel)
	EndIf     	

Return

/*/{Protheus.doc} AfterTTS
	Metodo responsable por ejecutar reglas de negocio de retenciones 
	despu�s de la transacci�n del modelo de datos.
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		26/08/2026 
	@param      oModel, Object, Modelo de dados
	@param 		cModelId, Character, Identificador do sub-modelo
/*/
Method AfterTTS(oModel, cModelId) Class F999RETBOL
Local nOperation	:= oModel:GetOperation()
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelEOP 	:= oModel:GetModel('EOP_MASTER')
Local oJImp 		:= JsonObject():New()

	If nOperation == MODEL_OPERATION_INSERT .And. !oModelEOP:GetValue("HASERROR")

		If self:lF850Ret
			oJImp['I']  := {"IR-","IRIC"}
			F999PERet(oModelSFE, oJImp, "A085ARET")
		EndIf

	EndIf

	FreeObj(oJImp)

Return Nil

/*/{Protheus.doc} F999UPDRET
	Metodo responsable por realizar las actualizaciones en el modelo de retenciones
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2025 
	@param      oModel, Object, Modelo de dados
/*/
Method F999UPDRET(oModel) Class F999RETBOL
Local nTamNum	:= GetSx3Cache("EK_NUM","X3_TAMANHO")
Local nTamMoe	:= GetSx3Cache("EK_MOEDA","X3_TAMANHO")
Local cFilSFE	:= xFilial("SFE")
Local cFilSEK	:= xFilial("SEK")

Default oModel := Nil

	UPDRETIRIC(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

	UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)

Return Nil

/*/{Protheus.doc} UPDRETIVA
	Funci�n que se encarga de actualizar las retenciones de IRIC en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Static Function UPDRETIRIC(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "I" .And. oModelSFE:GetValue("FE_RETENC") != 0 .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 

			cNroCert  := F999GetCert("IRIC  ", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"IRIC")
			oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
			oModelSFE:LoadValue("FE_NROCERT", cNroCert)
			oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
			oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
			oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))

			If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
				oModelTTB:AddLine()
			EndIf

			oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
			oModelTTB:LoadValue("EK_TIPODOC", "RG")
			oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
			oModelTTB:LoadValue("EK_TIPO"	, "IR-")
			oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
			oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_RETENC")) 
			oModelTTB:LoadValue("EK_VALOR"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_SALDO"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
			oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
			oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
			oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
			oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
			
			F999GrvTx(,,,, oModelMOE, oModelTTB)

			F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, oModelSFE:GetValue("FE_RETENC"))
		EndIf
	Next

Return Nil

/*/{Protheus.doc} UPDRETIR
	Funci�n que se encarga de actualizar las retenciones de IR en el modelo
	@type 		Method
	@author 	carlos.espinoza
	@version	12.1.2310 / Superior
	@since		16/01/2026 
	@param 		oModel, Object, Modelo de dados
	@param 		nTamNum, Numeric, Tama�o del campo EK_NUM
	@param 		nTamMoe, Numeric, Tama�o del campo EK_MOEDA
	@param 		cFilSFE, Character, xFilial() de la tabla SFE
	@param 		cFilSEK, Character, xFilial() de la tabla SEK
/*/
Static Function UPDRETIR(oModel, nTamNum, nTamMoe, cFilSFE, cFilSEK)
Local oModelTTB 	:= oModel:GetModel('TTB_DETAIL')
Local oModelSFE 	:= oModel:GetModel('SFE_DETAIL')
Local oModelMOE 	:= oModel:GetModel('MOE_DETAIL')
Local oModelFJR 	:= oModel:GetModel('FJR_MASTER')
Local oModelSOP 	:= oModel:GetModel('SOP_DETAIL')
Local nX 			:= 1
Local cNroCert		:= ""

Default oModel 		:= Nil
Default nTamNum 	:= 0
Default nTamMoe 	:= 0
Default cFilSFE 	:= ""
Default cFilSEK 	:= ""

	For nX := 1 To oModelSFE:Length()
		oModelSFE:GoLine(nX)
		If oModelSFE:GetValue("FE_TIPO") == "R" .And. oModelSFE:GetValue("FE_RETENC") != 0 .And. !Empty(oModelSFE:GetValue("FE_NFISCAL"))
			oModelFJR:SeekLine({{"FJR_ORDPAG", oModelSFE:GetValue("FE_ORDPAGO")}}, .F., .T.) 

			cNroCert  := F999GetCert("IR    ", oModelFJR:GetValue("FJR_FORNEC")+oModelFJR:GetValue("FJR_LOJA")+"IR")
			oModelSFE:LoadValue("FE_FILIAL" , cFilSFE)
			oModelSFE:LoadValue("FE_NROCERT", cNroCert)
			oModelSFE:LoadValue("FE_EMISSAO", dDataBase)
			oModelSFE:LoadValue("FE_FORNECE", oModelFJR:GetValue("FJR_FORNEC"))
			oModelSFE:LoadValue("FE_LOJA"	, oModelFJR:GetValue("FJR_LOJA"))
			oModelSFE:LoadValue("FE_TIPO"	, "I")

			If !Empty(oModelTTB:GetValue("EK_ORDPAGO"))
				oModelTTB:AddLine()
			EndIf

			oModelTTB:LoadValue("EK_FILIAL" , cFilSEK)
			oModelTTB:LoadValue("EK_TIPODOC", "RG")
			oModelTTB:LoadValue("EK_NUM"	, StrZero(VAL(cNroCert),nTamNum))
			oModelTTB:LoadValue("EK_TIPO"	, "IR-")
			oModelTTB:LoadValue("EK_EMISSAO", dDataBase)
			oModelTTB:LoadValue("EK_VLMOED1", oModelSFE:GetValue("FE_RETENC")) 
			oModelTTB:LoadValue("EK_VALOR"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_SALDO"	, oModelSFE:GetValue("FE_RETENC"))
			oModelTTB:LoadValue("EK_VENCTO"	, dDataBase)
			oModelTTB:LoadValue("EK_FORNECE", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJA"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_MOEDA"	, StrZero(oModelFJR:GetValue("NMOERET"),nTamMoe))
			oModelTTB:LoadValue("EK_ORDPAGO", oModelSFE:GetValue("FE_ORDPAGO"))
			oModelTTB:LoadValue("EK_DTDIGIT", dDataBase)
			oModelTTB:LoadValue("EK_FORNEPG", oModelSFE:GetValue("FE_FORNECE"))
			oModelTTB:LoadValue("EK_LOJAPG"	, oModelSFE:GetValue("FE_LOJA"))
			oModelTTB:LoadValue("EK_NATUREZ", oModelFJR:GetValue("FJR_NATURE"))
			
			F999GrvTx(,,,, oModelMOE, oModelTTB)

			F999ActSal(oModelSOP, oModelSFE:GetValue("FE_ORDPAGO"), 1, oModelSFE:GetValue("FE_RETENC"))
		EndIf
	Next

Return Nil
