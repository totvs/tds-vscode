#include 'totvs.ch'
#include 'fwmvcdef.ch'
#include 'fina999.ch'

#DEFINE SOURCEFATHER "FINA999"

/*/{Protheus.doc} FINA999BOL
	Fuente de Modelo de Datos de Orden de Pago Localizado para Bolivia
	@type 		Function
	@author 	carlos.espinoza
	@since 		24/08/2026
	@version	12.1.2310 / Superior
/*/
Function FINA999BOL()
Local oBrowse	:= Nil

	oBrowse := BrowseDef()
	oBrowse:Activate()
	
Return Nil

/*/{Protheus.doc} BrowseDef
	Definici�n de Browse
	@type 		Function
	@author	 	carlos.espinoza
	@since 		24/08/2026
	@version	12.1.2310 / Superior
/*/
Static Function BrowseDef()
Local oBrowse := Nil

	oBrowse := FwLoadBrw(SOURCEFATHER)

Return oBrowse

/*/{Protheus.doc} MenuDef
	Define las operaciones que ser�n realizadas por la aplicaci�n
	@type 		Function
	@author 	carlos.espinoza
	@since 		24/08/2026
	@version	12.1.2310 / Superior
/*/
Static Function MenuDef()
Local aRotina := {}
	
aRotina := FWLoadMenuDef(SOURCEFATHER)

Return aRotina

/*/{Protheus.doc} ModelDef
	Defini��o do modelo de Dados
	@type 		Function
	@author 	carlos.espinoza
	@since 		24/08/2026
	@version	12.1.2310 / Superior
	@return		Object, Modelo de dados
/*/
Static Function ModelDef()
Local oModel		:= FwLoadModel(SOURCEFATHER)
Local oStruSFE		:= FWFormStruct(1, 'SFE', , .F.)
Local oRetEvent		:= F999RETBOL():New()

	oModel:addGrid('SFE_DETAIL','EOP_MASTER',oStruSFE,,)	// Retenciones

	oModel:GetModel('SFE_DETAIL'):SetOptional(.T.)
	
	oStruSFE:SetProperty('*' , MODEL_FIELD_OBRIGAT,	.F.)

	oStruSFE:SetProperty('FE_ORDPAGO', MODEL_FIELD_VALUES , "") 

	//Evento del Modelo
	oModel:InstallEvent("F999RETBOL",/*cOwner*/,oRetEvent)

Return oModel

/*/{Protheus.doc} ViewDef
	Interface del modelo de datos de Orden de Pago
	@type 		Function
	@author 	carlos.espinoza
	@since 		24/08/2026
	@version	12.1.2310 / Superior
	@return		Object, Vista del Modelo de dados
/*/
Static Function ViewDef()
Local oView		:= FWLoadView(SOURCEFATHER)
Local oModel    := Nil

	oModel := oView:GetModel()

Return oView
